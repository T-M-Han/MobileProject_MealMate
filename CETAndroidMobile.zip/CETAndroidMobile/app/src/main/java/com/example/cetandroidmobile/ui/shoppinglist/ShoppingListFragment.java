package com.example.cetandroidmobile.ui.shoppinglist;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cetandroidmobile.DBHelper;
import com.example.cetandroidmobile.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShoppingListFragment extends Fragment implements SensorEventListener {

    // Constants for SMS and shake detection
    private static final int REQUEST_SMS_PERMISSION = 1;
    private static final float SHAKE_THRESHOLD_GRAVITY = 1.5f;
    private static final int SHAKE_TIME_MS = 1000;

    // UI components
    private RecyclerView recyclerViewShoppingList;
    private ShoppingListAdapter shoppingListAdapter;
    private AppCompatImageButton fabSendSMS;

    // User information
    private String userEmail;
    private int userId;

    // Sensor components
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private long lastShakeTime;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout
        View root = inflater.inflate(R.layout.fragment_shopping_list, container, false);

        // Initialize RecyclerView
        recyclerViewShoppingList = root.findViewById(R.id.recyclerViewShoppingList);
        recyclerViewShoppingList.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize SensorManager for shake detection
        sensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }

        // Retrieve user email from SharedPreferences
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        userEmail = sharedPreferences.getString("user_email", "");

        // Fetch userId based on email
        if (userEmail != null && !userEmail.isEmpty()) {
            fetchUserIdFromEmail(userEmail);
        }

        // Refresh shopping list data and set up SMS functionality
        refreshFragment();
        checkAndSendShoppingListViaSMS();
        enableSwipeToDelete();

        // Set up SMS send button
        fabSendSMS = root.findViewById(R.id.fabSendSMS);
        fabSendSMS.setOnClickListener(v -> checkAndSendShoppingListViaSMS());

        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Register the accelerometer sensor listener
        if (sensorManager != null && accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        // Unregister the accelerometer sensor listener
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Detect shake events
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            float gX = x / SensorManager.GRAVITY_EARTH;
            float gY = y / SensorManager.GRAVITY_EARTH;
            float gZ = z / SensorManager.GRAVITY_EARTH;

            float gForce = (float) Math.sqrt(gX * gX + gY * gY + gZ * gZ);

            if (gForce > SHAKE_THRESHOLD_GRAVITY) {
                long currentTime = System.currentTimeMillis();
                if (currentTime - lastShakeTime > SHAKE_TIME_MS) {
                    lastShakeTime = currentTime;
                    checkAndSendShoppingListViaSMS();
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not used in this implementation
    }

    private void enableSwipeToDelete() {
        // Set up swipe-to-delete functionality
        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                // Remove item on swipe and refresh
                int position = viewHolder.getAdapterPosition();
                shoppingListAdapter.removeItem(position);
                refreshFragment();
            }

            @Override
            public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                // Draw swipe-to-delete background and text
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE && isCurrentlyActive) {
                    View itemView = viewHolder.itemView;
                    Paint paint = new Paint();
                    paint.setColor(Color.RED);
                    paint.setAlpha(100);

                    if (dX > 0) {
                        c.drawRect(itemView.getLeft(), itemView.getTop(), itemView.getLeft() + dX, itemView.getBottom(), paint);
                    }

                    paint.setColor(Color.WHITE);
                    paint.setTextSize(50);
                    paint.setTextAlign(Paint.Align.CENTER);
                    c.drawText("DELETE", itemView.getLeft() + dX / 2, itemView.getTop() + (itemView.getHeight() / 2), paint);
                }
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            }
        };
        new ItemTouchHelper(simpleCallback).attachToRecyclerView(recyclerViewShoppingList);
    }

    private void fetchUserIdFromEmail(String userEmail) {
        // Retrieve userId from the database based on email
        DBHelper dbHelper = new DBHelper(getContext());
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT user_id FROM user WHERE email = ?", new String[]{userEmail});

        if (cursor != null && cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndex("user_id"));
        }
        if (cursor != null) {
            cursor.close();
        }
        db.close();
    }

    private Map<String, List<ShoppingListItem>> fetchShoppingListItemsGroupedByCategory(Context context, int userId) {
        // Fetch shopping list items grouped by category
        Map<String, List<ShoppingListItem>> groupedItems = new HashMap<>();
        DBHelper dbHelper = new DBHelper(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT DISTINCT sl.ingredient_name, sl.category, sl.is_purchased, m.meal_name " +
                        "FROM planner p " +
                        "JOIN meals m ON p.meal_id = m.meal_id " +
                        "JOIN ingredients i ON m.meal_id = i.meal_id " +
                        "JOIN shopping_list sl ON sl.ingredient_name = i.ingredient_name " +
                        "WHERE p.user_id = ?",
                new String[]{String.valueOf(userId)}
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String ingredientName = cursor.getString(cursor.getColumnIndex("ingredient_name"));
                String category = cursor.getString(cursor.getColumnIndex("category"));
                boolean isPurchased = cursor.getInt(cursor.getColumnIndex("is_purchased")) == 1;
                String mealName = cursor.getString(cursor.getColumnIndex("meal_name"));

                ShoppingListItem item = new ShoppingListItem(ingredientName, category, isPurchased, mealName);

                if (!isDuplicate(groupedItems, item)) {
                    groupedItems.computeIfAbsent(category, k -> new ArrayList<>()).add(item);
                }
            }
            cursor.close();
        }
        db.close();
        return groupedItems;
    }

    private boolean isDuplicate(Map<String, List<ShoppingListItem>> groupedItems, ShoppingListItem newItem) {
        // Check for duplicate shopping list items
        List<ShoppingListItem> itemsInCategory = groupedItems.get(newItem.getCategory());
        if (itemsInCategory != null) {
            for (ShoppingListItem item : itemsInCategory) {
                if (item.getIngredientName().equals(newItem.getIngredientName())
                        && item.getMealName().equals(newItem.getMealName())) {
                    return true;
                }
            }
        }
        return false;
    }

    private void refreshFragment() {
        // Refresh the shopping list data
        Map<String, List<ShoppingListItem>> groupedItems = fetchShoppingListItemsGroupedByCategory(getContext(), userId);
        if (shoppingListAdapter == null) {
            shoppingListAdapter = new ShoppingListAdapter(groupedItems, this, getContext());
            recyclerViewShoppingList.setAdapter(shoppingListAdapter);
        } else {
            shoppingListAdapter.updateData(groupedItems);
        }

        if (groupedItems.isEmpty()) {
            showCustomToast("Your shopping list is empty. Start adding items!", false);
        }
    }

    public void showCustomToast(String message, boolean isSuccess) {
        // Display a custom toast message
        LayoutInflater inflater = getLayoutInflater();
        View toastLayout = inflater.inflate(R.layout.custom_toast, null);

        TextView toastMessage = toastLayout.findViewById(R.id.toast_message);
        toastMessage.setText(message);

        ImageView toastIcon = toastLayout.findViewById(R.id.toast_icon);
        toastIcon.setImageResource(isSuccess ? R.drawable.ic_success : R.drawable.ic_error);

        Toast toast = new Toast(getContext().getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastLayout);
        toast.show();
    }

    private void checkAndSendShoppingListViaSMS() {
        // Check SMS permissions and send the shopping list
        if (ContextCompat.checkSelfPermission(getContext(), android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{android.Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
        } else {
            sendShoppingListViaSMS();
        }
    }

    private void sendShoppingListViaSMS() {
        // Compile and send the shopping list via SMS
        Map<String, List<ShoppingListItem>> groupedItems = fetchShoppingListItemsGroupedByCategory(getContext(), userId);

        if (groupedItems.isEmpty()) {
            showCustomToast("Your shopping list is empty. Add items to send via SMS.", false);
            return;
        }

        StringBuilder message = new StringBuilder();
        for (Map.Entry<String, List<ShoppingListItem>> entry : groupedItems.entrySet()) {
            String category = entry.getKey();
            List<ShoppingListItem> items = entry.getValue();

            message.append(category).append(":\n");
            for (ShoppingListItem item : items) {
                message.append("- ").append(item.getIngredientName())
                        .append(" (Meal: ").append(item.getMealName()).append(")\n");
            }
            message.append("\n");
        }

        if (message.length() > 0 && message.charAt(message.length() - 1) == '\n') {
            message.setLength(message.length() - 1);
        }

        Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
        smsIntent.setData(Uri.parse("sms:"));
        smsIntent.putExtra("sms_body", message.toString());

        if (smsIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivity(smsIntent);
        } else {
            showCustomToast("No SMS app found", false);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        // Handle SMS permission result
        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendShoppingListViaSMS();
            } else {
                showCustomToast("Permission denied. Unable to send SMS.", false);
            }
        }
    }
}
