package com.example.cetandroidmobile.ui.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.cetandroidmobile.R;

import java.util.List;

public class MealAdapter extends RecyclerView.Adapter<MealAdapter.MealViewHolder> {

    private final Context context;
    private final List<Meal> meals;
    private OnItemClickListener onItemClickListener;

    public MealAdapter(Context context, List<Meal> meals) {
        this.context = context;
        this.meals = meals;
    }

    // Interface for handling item clicks
    public interface OnItemClickListener {
        void onItemClick(Meal meal);
    }

    // Set the item click listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    @NonNull
    @Override
    public MealViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout for each RecyclerView item
        View view = LayoutInflater.from(context).inflate(R.layout.item_meal, parent, false);
        return new MealViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MealViewHolder holder, int position) {
        // Get the current meal object
        Meal meal = meals.get(position);

        // Set the meal name and meal type
        holder.mealName.setText(meal.getMealName());
        holder.mealType.setText(meal.getMealType());

        // Use Glide to load the image
        if (meal.getImageBlob() != null) {
            // Load image directly from BLOB (byte[])
            Glide.with(context)
                    .asBitmap()
                    .load(meal.getImageBlob()) // Load byte[] directly
                    .placeholder(R.drawable.default_image)
                    .error(R.drawable.default_image)
                    .into(holder.mealImage);
        } else if (meal.getImagePath() != null && !meal.getImagePath().isEmpty()) {
            // Load image from drawable resource path
            int resourceId = context.getResources().getIdentifier(meal.getImagePath(), "drawable", context.getPackageName());
            Glide.with(context)
                    .load(resourceId != 0 ? resourceId : R.drawable.default_image)
                    .placeholder(R.drawable.default_image)
                    .error(R.drawable.default_image)
                    .into(holder.mealImage);
        } else {
            // Set default image if no image data is available
            holder.mealImage.setImageResource(R.drawable.default_image);
        }

        // Handle click events
        holder.itemView.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onItemClick(meal); // Pass the clicked meal object
            }
        });
    }

    @Override
    public int getItemCount() {
        return meals.size();
    }

    // ViewHolder class to hold item views
    public static class MealViewHolder extends RecyclerView.ViewHolder {
        ImageView mealImage;
        TextView mealName, mealType;

        public MealViewHolder(@NonNull View itemView) {
            super(itemView);
            mealImage = itemView.findViewById(R.id.mealImage);
            mealName = itemView.findViewById(R.id.mealName);
            mealType = itemView.findViewById(R.id.mealType);
        }
    }
}