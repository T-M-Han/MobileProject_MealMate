package com.example.cetandroidmobile;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.Calendar;
import java.util.List;
import android.util.Pair;
import android.widget.Toast;

public class MealDetails extends AppCompatActivity {

    // UI elements
    private ImageView mealImageView;
    private TextView mealNameTextView, mealTypeTextView;
    private TableLayout ingredientsTable, preparationStepsTable;
    // Data variables
    private int mealId;
    private String userEmail;
    private int userId;
    private int createdBy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meal_details);

        // Enable back button in the Action Bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Meal Details");

        setupDeleteMealButton();

        // Initialize views
        mealImageView = findViewById(R.id.mealImageView);
        mealNameTextView = findViewById(R.id.mealNameTextView);
        mealTypeTextView = findViewById(R.id.mealTypeTextView);
        ingredientsTable = findViewById(R.id.ingredientsTable);
        preparationStepsTable = findViewById(R.id.preparationStepsTable);

        Button addToPlannerButton = findViewById(R.id.addToPlannerButton);
        addToPlannerButton.setOnClickListener(view -> checkLoginStatusAndProceed());

        // Get the meal ID and user email from the Intent
        Intent intent = getIntent();
        mealId = intent.getIntExtra("meal_id", -1);
        userEmail = intent.getStringExtra("user_email");

        if (mealId != -1) {
            fetchMealDetails(mealId);
        } else {
            showCustomToast("Invalid Meal ID!",false);
            finish();
        }

        if (userEmail != null) {
            fetchUserIdFromEmail(userEmail);
        } else {
            userId = 0;
        }
        refresh();
        updateDeleteMealButtonVisibility(userEmail);
    }

    private void showCustomToast(String message, boolean isSuccess) {
        LayoutInflater inflater = getLayoutInflater();
        View toastLayout = inflater.inflate(R.layout.custom_toast, null);

        // Set the message
        TextView toastMessage = toastLayout.findViewById(R.id.toast_message);
        toastMessage.setText(message);

        // Set icon based on success or failure
        ImageView toastIcon = toastLayout.findViewById(R.id.toast_icon);
        if (isSuccess) {
            toastIcon.setImageResource(R.drawable.ic_success); // Success icon
        } else {
            toastIcon.setImageResource(R.drawable.ic_error); // Error icon
        }
        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastLayout);
        toast.show();
    }

    // Fetch user ID from the database based on user email
    private void fetchUserIdFromEmail(String userEmail) {
        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.rawQuery("SELECT user_id FROM user WHERE email = ?", new String[]{userEmail});
            if (cursor != null && cursor.moveToFirst()) {
                userId = cursor.getInt(cursor.getColumnIndex("user_id"));
            } else {
                userId = 0; // Default to guest behavior if no user ID is found
            }
        } catch (Exception e) {
            Log.e("MealDetails", "Error fetching user ID", e);
            userId = 0;
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
    }

    // Check login status and show appropriate behavior
    private void checkLoginStatusAndProceed() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
        String userEmail = sharedPreferences.getString("user_email", "");

        if (isLoggedIn && !"Guest".equals(userEmail)) {
            showDatePickerDialog();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("Login Required")
                    .setMessage("You need to log in or sign up to add a meal to your planner.")
                    .setPositiveButton("Log In", (dialog, which) -> {
                        // Navigate to the login screen
                        Intent intent = new Intent(this, LoginActivity.class);
                        startActivity(intent);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        long today = calendar.getTimeInMillis();

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            String selectedDate = selectedYear + "-" + (selectedMonth + 1) + "-" + selectedDay;
            addMealToPlanner(mealId, selectedDate);
        }, year, month, day);

        datePickerDialog.getDatePicker().setMinDate(today);
        datePickerDialog.show();
    }

    private void addMealToPlanner(int mealId, String date) {
        if (userId == 0) {
            showCustomToast("User is not logged in or user is not found",false);
            return;
        }
        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues plannerValues = new ContentValues();
        plannerValues.put("meal_id", mealId);
        plannerValues.put("user_id", userId);
        plannerValues.put("date", date);
        long plannerResult = db.insert("planner", null, plannerValues);

        if (plannerResult != -1) {
            addIngredientsToShoppingList(db, mealId);
            showCustomToast("Meal added to planner and Groceries list updated!",true);
        } else {
            showCustomToast("Failed to add meal to planner.",false);
        }
        db.close();
    }

    private void addIngredientsToShoppingList(SQLiteDatabase db, int mealId) {
        // Fetch ingredients for the given meal
        List<Pair<String, String>> ingredients = new DBHelper(this).getIngredientsWithCategory(mealId);

        for (Pair<String, String> ingredient : ingredients) {
            ContentValues shoppingListValues = new ContentValues();
            shoppingListValues.put("user_id", userId);
            shoppingListValues.put("meal_id", mealId);
            shoppingListValues.put("ingredient_name", ingredient.first);
            shoppingListValues.put("category", ingredient.second);

            // Insert ingredient into shopping_list table
            long shoppingListResult = db.insert("shopping_list", null, shoppingListValues);

            if (shoppingListResult == -1) {
                Log.e("ShoppingList", "Failed to add ingredient: " + ingredient.first);
            }
        }
    }

    private void fetchMealDetails(int mealId) {
        DBHelper dbHelper = new DBHelper(this);

        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM meals WHERE meal_id = ?", new String[]{String.valueOf(mealId)});

            if (cursor != null && cursor.moveToFirst()) {
                // Retrieve meal details
                String mealName = cursor.getString(cursor.getColumnIndex("meal_name"));
                String mealType = cursor.getString(cursor.getColumnIndex("meal_type"));
                String imagePath = cursor.getString(cursor.getColumnIndex("image_path"));
                byte[] imageBlob = cursor.getBlob(cursor.getColumnIndex("image_blob"));
                createdBy = cursor.getInt(cursor.getColumnIndex("created_by"));

                // Set meal details to views
                mealNameTextView.setText(mealName);
                mealTypeTextView.setText(mealType);

                // Load image
                loadMealImage(imagePath, imageBlob);
                cursor.close();
            } else {
                showCustomToast("Meal not found!",false);
                finish();
            }
        } catch (Exception e) {
            Log.e("MealDetails", "Error fetching meal details", e);
            showCustomToast("Error fetching meal details!",false);
            finish();
        }
    }

    private void updateDeleteMealButtonVisibility(String email) {
        Button deleteMealButton = findViewById(R.id.deleteMealButton);

        // Hide the delete button if the meal is created by 0 or the user is a guest
        if (createdBy == 0 || "Guest".equals(email)) {
            deleteMealButton.setVisibility(View.GONE);
        } else {
            // Show the delete button if the user is logged in and the meal was created by them
            if (userId == createdBy) {
                deleteMealButton.setVisibility(View.VISIBLE);
            } else {
                deleteMealButton.setVisibility(View.GONE);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh the ingredients and preparation steps when the activity is resumed
        loadIngredientsAndPreparation(mealId);
        refresh();
    }

    public void refresh() {
        if (mealId != -1) {
            fetchMealDetails(mealId);
            loadIngredientsAndPreparation(mealId);
        } else {
            showCustomToast("Invalid Meal ID!",false);
            finish();
        }
    }

    private void loadMealImage(String imagePath, byte[] imageBlob) {
        if (imagePath != null && !imagePath.isEmpty()) {
            try {
                if (imagePath.startsWith("http") || imagePath.startsWith("www")) {
                    // Load from URL
                    Glide.with(this)
                            .load(imagePath)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .override(600, 600)
                            .into(mealImageView);
                } else {
                    int imageResId = getResources().getIdentifier(imagePath, "drawable", getPackageName());
                    if (imageResId != 0) {
                        Glide.with(this)
                                .load(imageResId)
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .override(300, 300)
                                .into(mealImageView);
                    } else {
                        mealImageView.setImageResource(R.drawable.default_image); // Fallback image
                    }
                }
            } catch (Exception e) {
                Log.e("MealDetails", "Error loading image from path: " + imagePath, e);
                mealImageView.setImageResource(R.drawable.default_image);
            }
        } else if (imageBlob != null && imageBlob.length > 0) {
            try {
                Bitmap bitmap = BitmapFactory.decodeByteArray(imageBlob, 0, imageBlob.length);
                mealImageView.setImageBitmap(bitmap);
            } catch (Exception e) {
                Log.e("MealDetails", "Error decoding image from BLOB", e);
                mealImageView.setImageResource(R.drawable.default_image);
            }
        } else {
            mealImageView.setImageResource(R.drawable.default_image);
        }
    }

    private void setupDeleteMealButton() {
        Button deleteMealButton = findViewById(R.id.deleteMealButton);
        deleteMealButton.setOnClickListener(view -> new AlertDialog.Builder(this)
                .setTitle("Delete Meal")
                .setMessage("Are you sure you want to delete this meal?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    deleteMeal(mealId);
                })
                .setNegativeButton("No", null)
                .show());
    }

    private void deleteMeal(int mealId) {
        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        int rowsDeleted = db.delete("meals", "meal_id = ?", new String[]{String.valueOf(mealId)});
        if (rowsDeleted > 0) {
            showCustomToast("Meal deleted successfully!",true);
            finish(); // Close the activity and go back
        } else {
            showCustomToast("Failed to delete meal.",false);
        }
        db.close();
    }

    private void loadIngredientsAndPreparation(int mealId) {
        DBHelper dbHelper = new DBHelper(this);

        // Fetch and populate ingredients
        List<Pair<String, String>> ingredients = dbHelper.getIngredientsWithQuantities(mealId);
        populateIngredientsTable(ingredients);

        // Fetch and populate preparation steps
        List<String> preparationSteps = dbHelper.getPreparationStepsAsList(mealId);
        populatePreparationStepsTable(preparationSteps);
    }

    private void populateIngredientsTable(List<Pair<String, String>> ingredients) {
        ingredientsTable.removeAllViews(); // Clear previous data
        for (Pair<String, String> ingredient : ingredients) {
            TableRow row = new TableRow(this);

            // Ingredient Name and Category
            TextView ingredientName = new TextView(this);
            ingredientName.setText(ingredient.first);
            ingredientName.setPadding(8, 8, 8, 8);
            ingredientName.setMaxLines(2);
            ingredientName.setEllipsize(android.text.TextUtils.TruncateAt.END);
            ingredientName.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1));

            // Ingredient Quantity
            TextView ingredientQuantity = new TextView(this);
            ingredientQuantity.setText(ingredient.second);
            ingredientQuantity.setPadding(8, 8, 8, 8);
            ingredientQuantity.setMaxLines(2);
            ingredientQuantity.setEllipsize(android.text.TextUtils.TruncateAt.END);
            ingredientQuantity.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1)); // Allow ingredient quantity to take available width

            row.addView(ingredientName);
            row.addView(ingredientQuantity);

            ingredientsTable.addView(row);
        }
    }

    private void populatePreparationStepsTable(List<String> preparationSteps) {
        preparationStepsTable.removeAllViews(); // Clear previous data
        int stepNumber = 1;

        for (String step : preparationSteps) {
            TableRow row = new TableRow(this);

            // Step Number
            TextView stepNumberText = new TextView(this);
            stepNumberText.setText(String.valueOf(stepNumber++));
            stepNumberText.setPadding(8, 8, 8, 8);

            // Step Instruction
            TextView stepInstruction = new TextView(this);
            stepInstruction.setText(step); // Instruction text
            stepInstruction.setPadding(8, 8, 8, 8);
            stepInstruction.setMaxLines(3);
            stepInstruction.setEllipsize(android.text.TextUtils.TruncateAt.END);
            stepInstruction.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1));

            row.addView(stepNumberText);
            row.addView(stepInstruction);

            preparationStepsTable.addView(row);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}