package com.example.cetandroidmobile;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CreateMealActivity extends AppCompatActivity {
    private static final int IMAGE_PICK_CODE = 1000;
    private EditText etMealName;
    private ImageView ivImagePreview;
    private Spinner spinnerMealType;
    private Button btnSubmitMeal, btnAddIngredient;
    private TableLayout ingredientsTable;
    private Uri imageUri;
    private Button btnAddStep;
    private LinearLayout stepsListContainer;
    private DBHelper dbHelper;
    private String userEmail;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_meal);

        dbHelper = new DBHelper(this);

        // Get the email passed from HomeFragment
        userEmail = getIntent().getStringExtra("user_email");

        if (userEmail == null || userEmail.isEmpty()) {
            // Handle case where no email is passed
            Toast.makeText(this, "No email found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the userId associated with the email
        userId = dbHelper.getUserIdByEmail(userEmail);
        if (userId == -1) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Initialize views
        btnAddStep = findViewById(R.id.btnAddStep);
        stepsListContainer = findViewById(R.id.stepsListContainer);
        etMealName = findViewById(R.id.etMealName);
        ivImagePreview = findViewById(R.id.ivImagePreview);
        spinnerMealType = findViewById(R.id.spinnerMealType);
        btnSubmitMeal = findViewById(R.id.btnSubmitMeal);
        btnAddIngredient = findViewById(R.id.btnAddIngredient);
        ingredientsTable = findViewById(R.id.ingredientsTable);

        // Validate that views are not null
        if (btnAddStep == null || stepsListContainer == null || etMealName == null ||
                ivImagePreview == null || spinnerMealType == null || btnSubmitMeal == null ||
                btnAddIngredient == null || ingredientsTable == null) {
            throw new IllegalStateException("One or more required views are not properly initialized.");
        }

        // Set up the Spinner with meal types
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.meal_types, // Reference to the string-array in resources
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMealType.setAdapter(adapter);

        // Validate the spinner adapter to ensure it's not empty
        if (getResources().getStringArray(R.array.meal_types).length == 0) {
            throw new IllegalStateException("The meal types array is empty.");
        }

        // Set up ImageView click listener for selecting an image
        ivImagePreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });

        // Set up the "Add Ingredient" button
        btnAddIngredient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddIngredientDialog();
            }
        });

        // Set up listeners for adding steps
        btnAddStep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (stepsListContainer == null) {
                    throw new IllegalStateException("Steps list container is not initialized.");
                }
                stepsListContainer.setVisibility(View.VISIBLE);
                //add a new step field if needed
                addStepField();
            }
        });

        btnSubmitMeal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSubmitMeal();
            }
        });

        // Setup window insets for Edge-to-Edge layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Method to handle image selection
    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Image"), IMAGE_PICK_CODE);
    }

    // Handle image picking result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == IMAGE_PICK_CODE && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData(); // Assign the selected image URI to the class-level variable
            if (imageUri != null) {
                // Set the selected image to the ImageView
                ivImagePreview.setImageURI(imageUri);
                //hide the placeholder text after image selection
                findViewById(R.id.tvUploadPhoto).setVisibility(View.GONE);
            } else {
                Toast.makeText(this, "Image selection failed. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method to add a new preparation step field dynamically
    private void addStepField() {
        // Create a new LinearLayout to hold the step label and input field
        LinearLayout stepLayout = new LinearLayout(this);
        stepLayout.setOrientation(LinearLayout.HORIZONTAL);
        stepLayout.setPadding(0, 16, 0, 16);

        // Create a TextView for the step number
        TextView stepLabel = new TextView(this);
        int stepNumber = stepsListContainer.getChildCount() + 1;
        stepLabel.setText("Step " + stepNumber + ": ");
        stepLabel.setTextSize(16);
        stepLabel.setPadding(8, 8, 16, 8);

        // Create an EditText for the step input
        EditText stepInput = new EditText(this);
        stepInput.setHint("Enter step " + stepNumber);
        stepInput.setTextSize(16);
        stepInput.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // Add the TextView and EditText to the step layout
        stepLayout.addView(stepLabel);
        stepLayout.addView(stepInput);

        // Add the step layout to the steps container
        stepsListContainer.addView(stepLayout);
    }

    private void handleSubmitMeal() {
        String mealName = etMealName.getText().toString().trim();
        String mealType = spinnerMealType.getSelectedItem().toString();

        byte[] imageBytes = null;
        if (imageUri != null) {
            imageBytes = imageUriToByteArray(imageUri);
        } else {
            showCustomToast("Please add an image for the meal",false);
            return;
        }
        if (mealName.isEmpty()) {
            showCustomToast("Please enter a meal name",false);
            return;
        }
        if (mealType.isEmpty()) {
            showCustomToast("Please select a meal type",false);
            return;
        }

        List<String> ingredientNames = new ArrayList<>();
        List<String> ingredientQuantities = new ArrayList<>();
        List<String> ingredientCategories = new ArrayList<>();

        for (int i = 1; i < ingredientsTable.getChildCount(); i++) {
            TableRow row = (TableRow) ingredientsTable.getChildAt(i);
            TextView nameTextView = (TextView) row.getChildAt(1);
            TextView quantityTextView = (TextView) row.getChildAt(2);
            TextView categoryTextView = (TextView) row.getChildAt(0);

            String name = nameTextView.getText().toString().trim();
            String quantity = quantityTextView.getText().toString().trim();
            String category = categoryTextView.getText().toString().trim();

            if (!name.isEmpty() && !quantity.isEmpty() && !category.isEmpty()) {
                ingredientNames.add(name);
                ingredientQuantities.add(quantity);
                ingredientCategories.add(category);
            } else if (name.isEmpty() || quantity.isEmpty() || category.isEmpty()) {
                showCustomToast("Please fill all fields for each ingredient",false);
                return;
            }
        }

        if (ingredientNames.isEmpty()) {
            showCustomToast("Please add at least one ingredient",false);
            return;
        }

        List<String> preparationSteps = new ArrayList<>();
        for (int i = 0; i < stepsListContainer.getChildCount(); i++) {
            LinearLayout stepLayout = (LinearLayout) stepsListContainer.getChildAt(i);
            EditText stepInput = (EditText) stepLayout.getChildAt(1);
            String step = stepInput.getText().toString().trim();

            if (!step.isEmpty()) {
                preparationSteps.add(step);
            }
        }

        if (preparationSteps.isEmpty()) {
            showCustomToast("Please add at least one preparation step",false);
            return;
        }
        saveMealToDatabase(mealName, mealType, preparationSteps, imageBytes, ingredientNames, ingredientQuantities, ingredientCategories, userEmail);
        finish();
    }

    private void showCustomToast(String message, boolean isSuccess) {
        LayoutInflater inflater = getLayoutInflater();
        View toastLayout = inflater.inflate(R.layout.custom_toast, null);

        // Set the message
        TextView toastMessage = toastLayout.findViewById(R.id.toast_message);
        toastMessage.setText(message);

        // Set icon based on success or failure
        ImageView toastIcon = toastLayout.findViewById(R.id.toast_icon);
        if (isSuccess) {
            toastIcon.setImageResource(R.drawable.ic_success); // Success icon
        } else {
            toastIcon.setImageResource(R.drawable.ic_error); // Error icon
        }
        // Show the Toast
        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastLayout);
        toast.show();
    }

    // Convert image to byte array method (same as before)
    private byte[] imageUriToByteArray(Uri imageUri) {
        try {
            InputStream imageStream = getContentResolver().openInputStream(imageUri);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
            selectedImage.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Method to show a dialog for adding an ingredient
    private void showAddIngredientDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_add_ingredient, null);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setView(dialogView);
        AlertDialog dialog = dialogBuilder.create();
        dialog.show();

        Spinner spinnerIngredientName = dialogView.findViewById(R.id.spinnerIngredientName);
        EditText etIngredientQuantity = dialogView.findViewById(R.id.etIngredientQuantity);
        Spinner spinnerCategory = dialogView.findViewById(R.id.spinnerIngredientCategory);
        Spinner spinnerUnits = dialogView.findViewById(R.id.spinnerUnits);
        Button btnAddCustomCategory = dialogView.findViewById(R.id.btnAddCustomCategory);
        Button btnAddCustomIngredient = dialogView.findViewById(R.id.btnAddCustomIngredient);
        Button btnAddCustomUnit = dialogView.findViewById(R.id.btnAddCustomUnit);
        Button btnAdd = dialogView.findViewById(R.id.btnAddIngredientDialog);
        Button btnCancel = dialogView.findViewById(R.id.btnCancelIngredientDialog);

        // Get all categories from the database
        List<String> categories = getCategoriesFromDatabase();

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(categoryAdapter);

        // Set up listener to update ingredient names based on category selection
        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedCategory = parentView.getItemAtPosition(position).toString();

                if (selectedCategory.isEmpty()) {
                    // If the selected category is blank, clear the ingredient names
                    ArrayAdapter<String> emptyAdapter = new ArrayAdapter<>(CreateMealActivity.this, android.R.layout.simple_spinner_item, new ArrayList<>());
                    emptyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerIngredientName.setAdapter(emptyAdapter);
                } else {
                    // Otherwise, load ingredients for the selected category
                    List<String> ingredientNames = getIngredientsByCategory(selectedCategory);
                    ArrayAdapter<String> ingredientAdapter = new ArrayAdapter<>(CreateMealActivity.this, android.R.layout.simple_spinner_item, ingredientNames);
                    ingredientAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerIngredientName.setAdapter(ingredientAdapter);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // No action needed
            }
        });

        // Load units from the string-array
        ArrayAdapter<CharSequence> unitAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.ingredient_units,
                android.R.layout.simple_spinner_item
        );
        unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerUnits.setAdapter(unitAdapter);

        // Add custom category functionality
        btnAddCustomCategory.setOnClickListener(v -> {
            AlertDialog.Builder customCategoryDialog = new AlertDialog.Builder(this);
            customCategoryDialog.setTitle("Enter Custom Category");

            final EditText input = new EditText(this);
            input.setHint("Category Name");
            customCategoryDialog.setView(input);

            customCategoryDialog.setPositiveButton("Add", (dialog1, which) -> {
                String customCategory = input.getText().toString().trim();

                if (customCategory.isEmpty()) {
                    showCustomToast("Please enter a valid category name.",false);
                } else if (customCategory.length() < 3 || customCategory.length() > 15) {
                    showCustomToast("Category name must be between 3 and 15 characters.",false);
                } else if (!categories.contains(customCategory)) {
                    categories.add(customCategory);
                    categoryAdapter.notifyDataSetChanged(); // Refresh spinner
                    spinnerCategory.setSelection(categories.indexOf(customCategory)); // Select the newly added category
                } else {
                    showCustomToast("Category already exists!",false);
                }
            });
            customCategoryDialog.setNegativeButton("Cancel", null);
            customCategoryDialog.show();
        });

        // Add custom ingredient functionality
        btnAddCustomIngredient.setOnClickListener(v -> {
            AlertDialog.Builder customIngredientDialog = new AlertDialog.Builder(this);
            customIngredientDialog.setTitle("Enter Custom Ingredient");

            // Create an EditText for input
            final EditText input = new EditText(this);
            input.setHint("Ingredient Name");
            customIngredientDialog.setView(input);

            // Add "Add" and "Cancel" buttons
            customIngredientDialog.setPositiveButton("Add", (dialog1, which) -> {
                String customIngredient = input.getText().toString().trim();

                if (customIngredient.isEmpty()) {
                    showCustomToast("Please enter a valid ingredient name.",false);
                } else if (customIngredient.length() < 2 || customIngredient.length() > 15) {
                    showCustomToast("Ingredient name must be between 2 and 15 characters.",false);
                } else {
                    // Check if the ingredient already exists
                    ArrayAdapter<String> ingredientAdapter = (ArrayAdapter<String>) spinnerIngredientName.getAdapter();
                    if (ingredientAdapter.getPosition(customIngredient) == -1) {
                        ingredientAdapter.add(customIngredient);
                        ingredientAdapter.notifyDataSetChanged();
                        spinnerIngredientName.setSelection(ingredientAdapter.getPosition(customIngredient));
                    } else {
                        showCustomToast("Ingredient already exists!",false);
                    }
                }
            });
            customIngredientDialog.setNegativeButton("Cancel", null);
            customIngredientDialog.show();
        });

        btnAddCustomUnit.setOnClickListener(v -> {
            AlertDialog.Builder customUnitDialog = new AlertDialog.Builder(this);
            customUnitDialog.setTitle("Enter Custom Unit");

            final EditText input = new EditText(this);
            customUnitDialog.setView(input);

            customUnitDialog.setPositiveButton("Add", (dialog1, which) -> {
                String newUnit = input.getText().toString().trim();
                if (newUnit.isEmpty()) {
                    showCustomToast("Please enter a valid unit name.",false);
                } else if (newUnit.length() < 1 || newUnit.length() > 10) {
                    showCustomToast("Unit name must be between 1 and 10 characters.",false);
                } else {
                    List<String> units = new ArrayList<>();
                    for (int i = 0; i < unitAdapter.getCount(); i++) {
                        units.add(unitAdapter.getItem(i).toString());
                    }
                    units.add(newUnit);

                    ArrayAdapter<String> updatedAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units);
                    updatedAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerUnits.setAdapter(updatedAdapter);

                    spinnerUnits.setSelection(units.indexOf(newUnit));
                }
            });
            customUnitDialog.setNegativeButton("Cancel", null);
            customUnitDialog.show();
        });

        // Add ingredient to the table
        btnAdd.setOnClickListener(v -> {
            String ingredientName = spinnerIngredientName.getSelectedItem() != null ?
                    spinnerIngredientName.getSelectedItem().toString().trim() : "";
            String ingredientQuantity = etIngredientQuantity.getText().toString().trim();
            String category = spinnerCategory.getSelectedItem() != null ?
                    spinnerCategory.getSelectedItem().toString().trim() : "";
            String unit = spinnerUnits.getSelectedItem() != null ?
                    spinnerUnits.getSelectedItem().toString().trim() : "";

            // Validate that required fields are filled
            if (ingredientName.isEmpty()) {
                showCustomToast("Please select or enter an ingredient name.",false);
                return;
            }

            if (ingredientQuantity.isEmpty()) {
                showCustomToast("Please enter a quantity.",false);
                return;
            }

            if (category.isEmpty()) {
                showCustomToast("Please select a category.",false);
                return;
            }
            // If all validations pass, add the ingredient to the table
            addIngredientToTable(ingredientName, ingredientQuantity, category, unit);
            dialog.dismiss();
        });
        btnCancel.setOnClickListener(v -> dialog.dismiss());
    }

    private List<String> getIngredientsByCategory(String category) {
        Set<String> ingredientNamesSet = new HashSet<>(); // Use a Set to ensure uniqueness
        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Query to get ingredients by category
        String query = "SELECT DISTINCT ingredient_name FROM ingredients WHERE ingredient_category = ?";
        Cursor cursor = db.rawQuery(query, new String[]{category});

        if (cursor.moveToFirst()) {
            do {
                String ingredientName = cursor.getString(cursor.getColumnIndex("ingredient_name"));
                ingredientNamesSet.add(ingredientName);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        // Convert Set back to List to match the return type
        return new ArrayList<>(ingredientNamesSet);
    }

    private List<String> getCategoriesFromDatabase() {
        List<String> categories = new ArrayList<>();
        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Query to get all distinct categories
        String query = "SELECT DISTINCT ingredient_category FROM ingredients";
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String category = cursor.getString(cursor.getColumnIndex("ingredient_category"));
                categories.add(category);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return categories;
    }

    // Method to dynamically add an ingredient row to the table
    private void addIngredientToTable(String ingredientName, String ingredientQuantity, String category, String unit) {
        TableLayout ingredientsTable = findViewById(R.id.ingredientsTable); // Ensure the TableLayout ID matches your XML

        // Create a new TableRow
        TableRow row = new TableRow(this);
        // Set layout parameters for the row
        TableRow.LayoutParams params = new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT
        );
        row.setLayoutParams(params);

        // Create and add the "Category" column
        TextView categoryTextView = new TextView(this);
        categoryTextView.setText(category);
        categoryTextView.setPadding(16, 16, 16, 16);
        row.addView(categoryTextView);

        // Create and add the "Ingredient Name" column
        TextView nameTextView = new TextView(this);
        nameTextView.setText(ingredientName);
        nameTextView.setPadding(16, 16, 16, 16);
        row.addView(nameTextView);

        // Create and add the "Quantity" column (includes the unit)
        TextView quantityTextView = new TextView(this);
        quantityTextView.setText(String.format("%s %s", ingredientQuantity, unit));
        quantityTextView.setPadding(16, 16, 16, 16);
        row.addView(quantityTextView);

        // Add a "Delete" button
        ImageButton deleteButton = new ImageButton(this);
        deleteButton.setImageResource(R.drawable.ic_delete); // Replace with your delete icon resource
        deleteButton.setBackgroundResource(0); // Remove the default background for a cleaner look
        deleteButton.setPadding(16, 16, 100, 16); // Set padding as needed
        deleteButton.setColorFilter(getColor(R.color.orange_500)); // Optional: set color filter for icon

        deleteButton.setOnClickListener(v -> {
            // Remove this row from the table
            ingredientsTable.removeView(row);
        });
        row.addView(deleteButton);
        ingredientsTable.addView(row);
    }

    // Method to save meal data to the database
    private void saveMealToDatabase(String mealName, String mealType, List<String> preparationSteps, byte[] imageBytes,
                                    List<String> ingredientNames, List<String> ingredientQuantities, List<String> ingredientCategories,
                                    String userEmail) {

        // Get the user ID from the email
        DBHelper dbHelper = new DBHelper(this);
        int userId = dbHelper.getUserIdByEmail(userEmail); // Get user ID by email

        // Convert preparation steps to a single string
        StringBuilder preparationInstructions = new StringBuilder();
        for (String step : preparationSteps) {
            preparationInstructions.append(step).append("\n");
        }

        // Insert meal into the database with the image stored as BLOB
        long mealId = dbHelper.insertMeal(mealName, mealType, preparationInstructions.toString(), userId, imageBytes); // Pass the preparationInstructions as a string

        if (mealId != -1) {
            // Insert each ingredient
            for (int i = 0; i < ingredientNames.size(); i++) {
                String name = ingredientNames.get(i);
                String quantity = ingredientQuantities.get(i);
                String category = ingredientCategories.get(i);

                // Insert ingredient data into the ingredients table
                dbHelper.insertIngredient(mealId, name, quantity, category);
            }
            // Show a success message
            showCustomToast("Meal and ingredients saved successfully!",true);
        } else {
            // Show an error message
            showCustomToast("Failed to save meal.",false);
        }
    }
}