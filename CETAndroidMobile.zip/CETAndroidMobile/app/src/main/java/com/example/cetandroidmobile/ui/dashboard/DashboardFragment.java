package com.example.cetandroidmobile.ui.dashboard;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cetandroidmobile.DBHelper;
import com.example.cetandroidmobile.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DashboardFragment extends Fragment {

    private RecyclerView recyclerViewPlanner;
    private PlannerAdapter plannerAdapter;
    private String userEmail;
    private int userId;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the fragment layout
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);

        // Initialize RecyclerView
        recyclerViewPlanner = root.findViewById(R.id.recyclerViewPlanner);
        recyclerViewPlanner.setLayoutManager(new LinearLayoutManager(getContext()));

        // Get user email from SharedPreferences
        android.content.SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserPrefs", getContext().MODE_PRIVATE);
        userEmail = sharedPreferences.getString("user_email", "");

        // Fetch user ID using the email
        if (userEmail != null && !userEmail.isEmpty()) {
            fetchUserIdFromEmail(userEmail);
        }

        // Fetch and set planner items for the user
        List<PlannerItem> plannerItems = fetchPlannerItems(getContext(), userId);
        plannerAdapter = new PlannerAdapter(plannerItems, this::showDatePickerDialog);
        recyclerViewPlanner.setAdapter(plannerAdapter);

        // Attach swipe gestures for planner items
        attachSwipeControls();

        return root;
    }

    // Fetch user ID based on the email
    private void fetchUserIdFromEmail(String userEmail) {
        DBHelper dbHelper = new DBHelper(getContext());
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT user_id FROM user WHERE email = ?", new String[]{userEmail});

        if (cursor != null && cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndex("user_id"));
            cursor.close();
        }
        db.close();
    }

    // Fetch planner items from the database for the given user
    private List<PlannerItem> fetchPlannerItems(Context context, int userId) {
        List<PlannerItem> plannerItems = new ArrayList<>();
        DBHelper dbHelper = new DBHelper(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT p.planner_id, m.meal_id, m.meal_name, m.meal_type, p.date, m.image_path, m.image_blob, p.status " +
                        "FROM planner p " +
                        "JOIN meals m ON p.meal_id = m.meal_id " +
                        "WHERE p.user_id = ? " +
                        "ORDER BY p.date ASC",
                new String[]{String.valueOf(userId)}
        );

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int plannerId = cursor.getInt(cursor.getColumnIndex("planner_id"));
                int mealId = cursor.getInt(cursor.getColumnIndex("meal_id"));
                String mealName = cursor.getString(cursor.getColumnIndex("meal_name"));
                String mealType = cursor.getString(cursor.getColumnIndex("meal_type"));
                String date = cursor.getString(cursor.getColumnIndex("date"));
                String imagePath = cursor.getString(cursor.getColumnIndex("image_path"));
                byte[] imageBlob = cursor.getBlob(cursor.getColumnIndex("image_blob"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));

                plannerItems.add(new PlannerItem(plannerId, mealId, mealName, mealType, date, imagePath, imageBlob, status));
            }
            cursor.close();
        }

        db.close();
        return plannerItems;
    }

    // Attach swipe gestures to handle planner item actions
    private void attachSwipeControls() {
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {

            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                PlannerItem itemToUpdate = plannerAdapter.getItem(position);

                DBHelper dbHelper = new DBHelper(getContext());
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues contentValues = new ContentValues();

                if (direction == ItemTouchHelper.RIGHT) { // Swipe right to toggle status
                    contentValues.put("status", itemToUpdate.getStatus() == 1 ? 0 : 1);
                    db.update("planner", contentValues, "planner_id = ?", new String[]{String.valueOf(itemToUpdate.getPlannerId())});
                    db.close();
                    plannerAdapter.toggleStatus(position);
                    plannerAdapter.notifyItemChanged(position);
                    showCustomToast("Meal status updated", true);
                } else if (direction == ItemTouchHelper.LEFT) { // Swipe left to delete item
                    deleteMealAndIngredients(userId, itemToUpdate.getMealId());
                    plannerAdapter.deleteItem(position);
                    plannerAdapter.notifyItemRemoved(position);
                    showCustomToast("Item deleted", true);
                }

                refreshPlannerItems();
            }

            @Override
            public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder,
                                    float dX, float dY, int actionState, boolean isCurrentlyActive) {
                View itemView = viewHolder.itemView;
                Paint paint = new Paint();
                RectF background;

                int position = viewHolder.getAdapterPosition();
                PlannerItem item = plannerAdapter.getItem(position);
                if (item == null) return;

                String statusText = item.getStatus() == 1 ? "Not Eat" : "Eat";

                if (dX > 0) { // Swiping to the right
                    paint.setColor(getResources().getColor(R.color.orange_300));
                    background = new RectF(itemView.getLeft(), itemView.getTop(), dX, itemView.getBottom());
                    c.drawRect(background, paint);

                    paint.setColor(Color.WHITE);
                    paint.setTextSize(40);
                    paint.setTextAlign(Paint.Align.LEFT);
                    c.drawText(statusText, itemView.getLeft() + 10, itemView.getTop() + (itemView.getHeight() / 2f + 20), paint);
                } else if (dX < 0) { // Swiping to the left
                    paint.setColor(Color.RED);
                    background = new RectF(itemView.getRight() + dX, itemView.getTop(), itemView.getRight(), itemView.getBottom());
                    c.drawRect(background, paint);

                    paint.setColor(Color.WHITE);
                    paint.setTextSize(40);
                    paint.setTextAlign(Paint.Align.RIGHT);
                    c.drawText("Delete", itemView.getRight() - 10, itemView.getTop() + (itemView.getHeight() / 2f + 20), paint);
                }
                itemView.setTranslationX(dX);
            }
        });

        itemTouchHelper.attachToRecyclerView(recyclerViewPlanner);
    }

    // Show a custom Toast message
    private void showCustomToast(String message, boolean isSuccess) {
        LayoutInflater inflater = getLayoutInflater();
        View toastLayout = inflater.inflate(R.layout.custom_toast, null);

        TextView toastMessage = toastLayout.findViewById(R.id.toast_message);
        toastMessage.setText(message);

        ImageView toastIcon = toastLayout.findViewById(R.id.toast_icon);
        toastIcon.setImageResource(isSuccess ? R.drawable.ic_success : R.drawable.ic_error);

        Toast toast = new Toast(getActivity().getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastLayout);
        toast.show();
    }

    // Refresh planner items after changes
    private void refreshPlannerItems() {
        List<PlannerItem> updatedPlannerItems = fetchPlannerItems(getContext(), userId);
        plannerAdapter.updateData(updatedPlannerItems);
    }

    // Delete a meal and its associated ingredients
    private void deleteMealAndIngredients(int userId, int mealId) {
        DBHelper dbHelper = new DBHelper(getContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            db.beginTransaction();
            db.delete("planner", "user_id = ? AND meal_id = ?", new String[]{String.valueOf(userId), String.valueOf(mealId)});
            db.delete("shopping_list", "user_id = ? AND meal_id = ?", new String[]{String.valueOf(userId), String.valueOf(mealId)});
            db.setTransactionSuccessful();
        } catch (Exception e) {
            Toast.makeText(getContext(), "Error deleting: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    // Show a date picker dialog for updating planner item date
    private void showDatePickerDialog(int plannerId) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                getContext(),
                (view, year, month, dayOfMonth) -> {
                    String selectedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth);
                    updatePlannerDate(plannerId, selectedDate);
                    refreshPlannerItems();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis());
        datePickerDialog.show();
    }

    // Update planner date in the database
    private void updatePlannerDate(int plannerId, String newDate) {
        DBHelper dbHelper = new DBHelper(getContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("date", newDate);
        db.update("planner", contentValues, "planner_id = ?", new String[]{String.valueOf(plannerId)});
        db.close();
    }
}
