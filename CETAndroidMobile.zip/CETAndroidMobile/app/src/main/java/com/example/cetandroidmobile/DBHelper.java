package com.example.cetandroidmobile;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.List;
import java.util.ArrayList;
import android.util.Pair;


public class DBHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DATABASE_NAME = "mealmate.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_USER = "user";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PROFILE_IMAGE = "profile_image";
    // Constructor
    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create user table
        String createUserTable = "CREATE TABLE user (" +
                "user_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL, " +
                "email TEXT NOT NULL UNIQUE, " +
                "password TEXT NOT NULL, " +
                "profile_image BLOB);";
        db.execSQL(createUserTable);

        // Create meals table
        String createmealsTable = "CREATE TABLE meals (" +
                "meal_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "meal_name TEXT NOT NULL, " +
                "meal_type TEXT NOT NULL, " +
                "preparation_instructions TEXT, " +
                "created_by INTEGER, " +
                "created_at TEXT DEFAULT (datetime('now', 'localtime')), " +
                "image_path TEXT, " +
                "image_blob BLOB, " +
                "FOREIGN KEY(created_by) REFERENCES user(user_id));";
        db.execSQL(createmealsTable);

        // Create ingredients table
        String createIngredientsTable = "CREATE TABLE ingredients (" +
                "ingredient_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "meal_id INTEGER NOT NULL, " +
                "ingredient_name TEXT NOT NULL, " +
                "quantity TEXT NOT NULL, " +
                "ingredient_category TEXT NOT NULL, " +
                "FOREIGN KEY(meal_id) REFERENCES meals(meal_id));";
        db.execSQL(createIngredientsTable);

        // Create planner table
        String createPlannerTable = "CREATE TABLE planner (" +
                "planner_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "meal_id INTEGER NOT NULL, " +
                "user_id INTEGER NOT NULL, " +
                "date TEXT NOT NULL, " +
                "status INTEGER DEFAULT 0, " +
                "FOREIGN KEY(meal_id) REFERENCES meals(meal_id) ON DELETE CASCADE, " +
                "FOREIGN KEY(user_id) REFERENCES user(user_id) ON DELETE CASCADE);";
        db.execSQL(createPlannerTable);

        // Create shopping_list table
        String createShoppingListTable = "CREATE TABLE IF NOT EXISTS shopping_list (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "meal_id INTEGER, " +
                "ingredient_name TEXT NOT NULL, " +
                "category TEXT NOT NULL, " +
                "is_purchased INTEGER DEFAULT 0, " +
                "FOREIGN KEY(user_id) REFERENCES user(user_id), " +
                "FOREIGN KEY(meal_id) REFERENCES meals(meal_id));";
        db.execSQL(createShoppingListTable);

        // Insert default meals into meals table with preparation_instructions
        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Spaghetti Bolognese', 'Main', 'Cook spaghetti according to package instructions.\\nIn a pan, brown the ground beef.\\nAdd tomato sauce and simmer for 10 minutes.\\nCombine spaghetti with sauce and serve hot.', 0, 'spaghetti_bolognese');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Chicken Curry', 'Main', 'Cut chicken into cubes.\\nHeat oil in a pan, add curry powder, and sauté for 2 minutes.\\nAdd chicken and cook until browned.\\nPour in coconut milk, simmer until chicken is cooked through.\\nServe with rice.', 0, 'chicken_curry');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Caesar Salad', 'Starter', 'Wash and chop lettuce.\\nToss lettuce with croutons, Caesar dressing, and Parmesan cheese.\\nServe immediately.', 0, 'caesar_salad');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Grilled Salmon', 'Main', 'Marinate salmon in olive oil, lemon juice, and spices for 30 minutes.\\nGrill the salmon for 4-5 minutes per side until flaky.\\nServe with steamed vegetables.', 0, 'grilled_salmon');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Vegetable Stir Fry', 'Main', 'Chop vegetables into bite-sized pieces.\\nHeat oil in a wok, add garlic and stir-fry vegetables for 5 minutes.\\nAdd soy sauce and stir well.\\nServe hot with rice or noodles.', 0, 'vegetable_stir_fry');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Beef Stroganoff', 'Main', 'Slice beef and mushrooms.\\nSauté beef in butter until browned.\\nAdd mushrooms and sour cream, simmer for 10 minutes.\\nServe over noodles or rice.', 0, 'beef_stroganoff');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Tomato Soup', 'Starter', 'Dice tomatoes and onions.\\nSauté onions in a pot, add tomatoes, and cook until soft.\\nBlend the mixture until smooth.\\nAdd vegetable stock and simmer for 10 minutes.\\nServe with bread.', 0, 'tomato_soup');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Tuna Sandwich', 'Snack', 'Drain tuna and mix with mayonnaise.\\nSpread tuna mixture onto bread slices.\\nAdd lettuce or tomato slices, close sandwich, and serve.', 0, 'tuna_sandwich');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Pancakes', 'Dessert', 'Mix flour, milk, and eggs into a smooth batter.\\nHeat a pan and pour in batter to form pancakes.\\nCook until bubbles form, flip, and cook the other side.\\nServe with syrup or fruits.', 0, 'pancakes');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Greek Salad', 'Starter', 'Chop cucumbers, tomatoes, and onions.\\nAdd feta cheese and olives.\\nToss with olive oil and vinegar.\\nServe chilled.', 0, 'greek_salad');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('BBQ Chicken Wings', 'Snack', 'Marinate chicken wings in BBQ sauce.\\nBake or grill wings at 200°C for 25-30 minutes.\\nServe hot with dipping sauce.', 0, 'bbq_chicken_wings');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Vegetable Lasagna', 'Main', 'Layer lasagna sheets with ricotta cheese, spinach, and tomato sauce.\\nRepeat layers, ending with cheese on top.\\nBake at 180°C for 30 minutes.\\nServe hot.', 0, 'vegetable_lasagna');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Fish Tacos', 'Snack', 'Season fish fillets and cook in a pan.\\nAssemble tacos with fish, shredded cabbage, and lime juice.\\nServe with salsa or guacamole.', 0, 'fish_tacos');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Chocolate Brownie', 'Dessert', 'Melt chocolate and butter together.\\nMix in flour and eggs.\\nPour into a baking tray and bake at 180°C for 20-25 minutes.\\nLet cool before slicing.', 0, 'chocolate_brownie');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Chicken Caesar Wrap', 'Snack', 'Fill tortilla wrap with grilled chicken, Caesar dressing, and lettuce.\\nRoll tightly and slice in half.\\nServe chilled or warm.', 0, 'chicken_caesar_wrap');");

        db.execSQL("INSERT INTO meals (meal_name, meal_type, preparation_instructions, created_by, image_path) VALUES " +
                "('Mango Smoothie', 'Drink', 'Blend mango, Greek yogurt, honey, milk, and ice cubes together until smooth.\\nPour into a glass and serve immediately.', 0, 'mango_smoothie');");

        // Insert data into ingredients table with ingredient category
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (1, 'Spaghetti', '200g', 'Carb');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (1, 'Ground Beef', '300g', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (1, 'Tomato Sauce', '1 cup', 'Sauce');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (1, 'Onion', '1 medium, chopped', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (1, 'Garlic', '2 cloves, minced', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (1, 'Olive Oil', '2 tbsp', 'Oil');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (1, 'Parmesan Cheese', 'To garnish', 'Dairy');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (2, 'Chicken Breast', '200g', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (2, 'Curry Powder', '2 tbsp', 'Spice');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (2, 'Coconut Milk', '1 cup', 'Liquid');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (2, 'Onion', '1 medium, chopped', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (2, 'Ginger', '1 tbsp, minced', 'Spice');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (2, 'Garlic', '2 cloves, minced', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (2, 'Vegetable Oil', '2 tbsp', 'Oil');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (3, 'Romaine Lettuce', '100g', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (3, 'Croutons', '50g', 'Carb');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (3, 'Caesar Dressing', '3 tbsp', 'Sauce');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (3, 'Parmesan Cheese', '30g, grated', 'Dairy');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (3, 'Chicken Breast', 'Optional, grilled', 'Protein');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (4, 'Salmon Fillet', '150g', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (4, 'Olive Oil', '2 tbsp', 'Oil');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (4, 'Lemon Juice', '1 tbsp', 'Liquid');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (4, 'Garlic', '1 clove, minced', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (4, 'Parsley', 'To garnish', 'Herb');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (4, 'Salt and Pepper', 'To taste', 'Spice');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (5, 'Mixed Vegetables', '200g', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (5, 'Soy Sauce', '2 tbsp', 'Liquid');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (5, 'Garlic', '2 cloves, minced', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (5, 'Sesame Oil', '1 tbsp', 'Oil');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (5, 'Ginger', '1 tbsp, minced', 'Spice');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (5, 'Spring Onions', '2 stalks, chopped', 'Vegetable');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (6, 'Beef Strips', '250g', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (6, 'Sour Cream', '100ml', 'Dairy');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (6, 'Mushrooms', '150g, sliced', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (6, 'Onion', '1 medium, chopped', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (6, 'Garlic', '2 cloves, minced', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (6, 'Butter', '2 tbsp', 'Fat');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (7, 'Tomatoes', '4 large', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (7, 'Onion', '1 medium, chopped', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (7, 'Vegetable Stock', '500ml', 'Liquid');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (7, 'Garlic', '2 cloves, minced', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (7, 'Olive Oil', '2 tbsp', 'Oil');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (7, 'Basil Leaves', 'To garnish', 'Herb');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (8, 'Tuna', '1 can', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (8, 'Bread', '2 slices', 'Carb');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (8, 'Mayonnaise', '2 tbsp', 'Sauce');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (8, 'Lettuce', '2 leaves', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (8, 'Salt and Pepper', 'To taste', 'Spice');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (9, 'Flour', '200g', 'Carb');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (9, 'Milk', '300ml', 'Liquid');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (9, 'Eggs', '2 large', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (9, 'Butter', 'For frying', 'Fat');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (9, 'Sugar', 'Optional, for serving', 'Sweetener');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (10, 'Cucumber', '100g', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (10, 'Feta Cheese', '50g', 'Dairy');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (10, 'Olives', '20g', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (10, 'Tomatoes', '2 medium', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (10, 'Olive Oil', '2 tbsp', 'Oil');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (10, 'Lemon Juice', '1 tbsp', 'Liquid');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (10, 'Oregano', 'To taste', 'Herb');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (11, 'Chicken Wings', '300g', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (11, 'BBQ Sauce', '100ml', 'Sauce');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (11, 'Honey', '2 tbsp', 'Sweetener');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (11, 'Garlic', '1 clove, minced', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (11, 'Paprika', '1 tsp', 'Spice');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (11, 'Salt and Pepper', 'To taste', 'Spice');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (12, 'Lasagna Sheets', '6', 'Carb');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (12, 'Ricotta Cheese', '150g', 'Dairy');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (12, 'Spinach', '100g', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (12, 'Mozzarella Cheese', '100g, shredded', 'Dairy');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (12, 'Tomato Sauce', '1 cup', 'Sauce');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (12, 'Parmesan Cheese', '30g, grated', 'Dairy');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (13, 'Fish Fillets', '200g', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (13, 'Tortillas', '3', 'Carb');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (13, 'Lime Juice', '2 tbsp', 'Liquid');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (13, 'Cabbage', '50g, shredded', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (13, 'Sour Cream', '3 tbsp', 'Dairy');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (13, 'Cilantro', 'To garnish', 'Herb');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (14, 'Chocolate', '100g', 'Sweetener');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (14, 'Flour', '100g', 'Carb');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (14, 'Butter', '100g', 'Fat');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (14, 'Sugar', '100g', 'Sweetener');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (14, 'Eggs', '2 large', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (14, 'Vanilla Extract', '1 tsp', 'Flavor');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (15, 'Chicken Breast', '100g', 'Protein');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (15, 'Tortilla Wrap', '1', 'Carb');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (15, 'Caesar Dressing', '2 tbsp', 'Sauce');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (15, 'Lettuce', '2 leaves', 'Vegetable');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (15, 'Parmesan Cheese', '10g', 'Dairy');");

        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (16, 'Mango', '1 large', 'Fruit');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (16, 'Greek Yogurt', '1/2 cup', 'Dairy');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (16, 'Honey', '1 tbsp', 'Sweetener');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (16, 'Milk', '1/2 cup', 'Liquid');");
        db.execSQL("INSERT INTO ingredients (meal_id, ingredient_name, quantity, ingredient_category) VALUES (16, 'Ice Cubes', '1/2 cup', 'Other');");

        Log.i("DBHelper", "Database and tables created successfully.");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS user");
        db.execSQL("DROP TABLE IF EXISTS meals");
        db.execSQL("DROP TABLE IF EXISTS ingredients");
        db.execSQL("DROP TABLE IF EXISTS planner");
        onCreate(db);
    }

    public boolean insertGoogleUser(String username, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("email", email);
        contentValues.put("password", "");
        contentValues.put("profile_image", (byte[]) null);

        long result = db.insert(TABLE_USER, null, contentValues);
        db.close();
        return result != -1;
    }

    public boolean isPasswordSet(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT password FROM user WHERE email = ?", new String[]{email});

        boolean isPasswordSet = false;
        if (cursor.moveToFirst()) {
            String password = cursor.getString(0);
            if (password != null && !password.isEmpty()) {
                isPasswordSet = true;
            }
        }
        cursor.close();
        return isPasswordSet;
    }

    //Method to update the password for users
    public void updatePassword(String email, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("password", newPassword);

        db.update("user", values, "email = ?", new String[]{email});
        db.close();
    }

    // Method to verify user login
    public boolean verifyUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user WHERE email = ? AND password = ?", new String[]{email, password});

        if (cursor != null && cursor.getCount() > 0) {
            cursor.close();
            return true;
        } else {
            cursor.close();
            return false;
        }
    }

    public int getUserIdByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        int userId = -1; // Default to -1 if user is not found

        Cursor cursor = null;
        try {
            String query = "SELECT user_id FROM user WHERE email = ?";
            cursor = db.rawQuery(query, new String[]{email});

            if (cursor.moveToFirst()) {
                userId = cursor.getInt(cursor.getColumnIndex("user_id"));
            }
        } catch (Exception e) {
            Log.e("DBHelper", "Error fetching user ID: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return userId;
    }

    public String getUsernameByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("user", new String[]{"username"}, "email = ?", new String[]{email}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            String username = cursor.getString(cursor.getColumnIndex("username"));
            cursor.close();
            return username;
        } else {
            cursor.close();
            return null;
        }
    }

    public boolean saveProfileImage(String email, byte[] imageBytes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_PROFILE_IMAGE, imageBytes);

        // Update the user's profile image where email matches
        int rowsUpdated = db.update(TABLE_USER, contentValues, COLUMN_EMAIL + " = ?", new String[]{email});
        db.close();

        return rowsUpdated > 0;
    }

    public byte[] getProfileImageByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, new String[]{COLUMN_PROFILE_IMAGE}, COLUMN_EMAIL + " = ?", new String[]{email}, null, null, null);

        byte[] imageBytes = null;
        if (cursor != null && cursor.moveToFirst()) {
            imageBytes = cursor.getBlob(cursor.getColumnIndex(COLUMN_PROFILE_IMAGE));
            cursor.close();
        }
        db.close();
        return imageBytes;
    }

    // Method to update user profile (username and email)
    public boolean updateUserProfile(String currentEmail, String newUsername, String newEmail) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", newUsername);
        contentValues.put("email", newEmail);

        int result = db.update("user", contentValues, "email = ?", new String[]{currentEmail});
        db.close();

        return result > 0;
    }

    public boolean deleteProfileImage(String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.putNull("profile_image");
        int rowsUpdated = db.update("user", values, "email = ?", new String[]{email});
        db.close();
        return rowsUpdated > 0;
    }

    public boolean changePassword(String email, String oldPassword, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM user WHERE email = ? AND password = ?", new String[]{email, oldPassword});
        if (cursor.getCount() > 0) {
            ContentValues values = new ContentValues();
            values.put("password", newPassword);
            int rowsUpdated = db.update("user", values, "email = ?", new String[]{email});
            cursor.close();
            db.close();
            return rowsUpdated > 0;
        }
        cursor.close();
        db.close();
        return false;
    }

    // Fetch ingredients with quantities
    public List<Pair<String, String>> getIngredientsWithQuantities(int mealId) {
        List<Pair<String, String>> ingredients = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT ingredient_name, quantity, ingredient_category FROM ingredients WHERE meal_id = ?", new String[]{String.valueOf(mealId)});

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String name = cursor.getString(0);
                String quantity = cursor.getString(1);
                String category = cursor.getString(2);
                String ingredientDetail = name + " (" + category + ")";
                ingredients.add(new Pair<>(ingredientDetail, quantity));
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return ingredients;
    }

    // Fetch preparation steps as a list
    public List<String> getPreparationStepsAsList(int mealId) {
        List<String> steps = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT preparation_instructions FROM meals WHERE meal_id = ?", new String[]{String.valueOf(mealId)});

        if (cursor != null && cursor.moveToFirst()) {
            // Get the preparation instructions as a single string
            String instructions = cursor.getString(0);

            // Replace \\n with the actual newline character
            instructions = instructions.replace("\\n", "\n");

            // Split the instructions into individual steps based on the newline character
            String[] instructionSteps = instructions.split("\n");

            // Loop through the steps and add them to the list
            for (String step : instructionSteps) {
                steps.add(step.trim());
            }
            cursor.close();
        }
        db.close();
        return steps;
    }

    public long insertMeal(String mealName, String mealType, String preparationInstructions, int createdBy, byte[] imageBlob) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("meal_name", mealName);
        contentValues.put("meal_type", mealType);
        contentValues.put("preparation_instructions", preparationInstructions);
        contentValues.put("created_by", createdBy);
        contentValues.put("image_blob", imageBlob);

        long mealId = db.insert("meals", null, contentValues);
        db.close();
        return mealId;
    }

    public long insertIngredient(long mealId, String ingredientName, String quantity, String ingredientCategory) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("meal_id", mealId);
        values.put("ingredient_name", ingredientName);
        values.put("quantity", quantity);
        values.put("ingredient_category", ingredientCategory);
        // Insert the row into the ingredients table and return the row ID
        return db.insert("ingredients", null, values);
    }

    public List<Pair<String, String>> getIngredientsWithCategory(int mealId) {
        List<Pair<String, String>> ingredients = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Fetch ingredient name and category from the ingredients table
        Cursor cursor = db.rawQuery("SELECT ingredient_name, ingredient_category FROM ingredients WHERE meal_id = ?",
                new String[]{String.valueOf(mealId)});

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String ingredientName = cursor.getString(cursor.getColumnIndex("ingredient_name"));
                String category = cursor.getString(cursor.getColumnIndex("ingredient_category"));
                ingredients.add(new Pair<>(ingredientName, category));
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return ingredients;
    }
}