package com.example.cetandroidmobile.ui.dashboard;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.cetandroidmobile.R;

import java.util.ArrayList;
import java.util.List;

public class PlannerAdapter extends RecyclerView.Adapter<PlannerAdapter.PlannerViewHolder> {

    private final List<PlannerItem> plannerItems; // List of planner items to display
    private final OnCalendarClickListener calendarClickListener; // Listener for calendar button clicks

    //Interface for handling calendar button clicks.
    public interface OnCalendarClickListener {
        void onCalendarClick(int plannerId);
    }

    //Constructor to initialize the adapter with data and a listener.
    public PlannerAdapter(List<PlannerItem> plannerItems, OnCalendarClickListener listener) {
        this.plannerItems = new ArrayList<>(plannerItems);
        this.calendarClickListener = listener;
    }

    @NonNull
    @Override
    public PlannerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each planner item
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.planner_item, parent, false);
        return new PlannerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlannerViewHolder holder, int position) {
        // Exit if the position is invalid
        if (position < 0 || position >= plannerItems.size()) {
            return;
        }

        // Get the current planner item and bind its data to the views
        PlannerItem item = plannerItems.get(position);
        holder.mealNameTextView.setText(item.getMealName());
        holder.mealTypeTextView.setText(item.getMealType());
        holder.dateTextView.setText(item.getDate());

        // Load the meal image
        loadMealImage(holder.mealImageView, item.getImagePath(), item.getImageBlob());

        // Apply background color and transparency based on the status
        if (item.getStatus() == 1) {
            holder.itemView.setBackgroundColor(Color.LTGRAY); // Grey for "eaten"
            holder.itemView.setAlpha(0.5f); // Semi-transparent
        } else {
            holder.itemView.setBackgroundColor(Color.WHITE); // Normal background
            holder.itemView.setAlpha(1.0f); // Full opacity
        }

        // Set the calendar button click listener
        holder.itemView.findViewById(R.id.calenderbtn).setOnClickListener(v -> {
            if (calendarClickListener != null) {
                calendarClickListener.onCalendarClick(item.getPlannerId());
            }
        });
    }

    //Loads the meal image into the provided ImageView using Glide or a fallback.
    private void loadMealImage(ImageView mealImageView, String imagePath, byte[] imageBlob) {
        if (imagePath != null && !imagePath.isEmpty()) {
            if (imagePath.startsWith("http") || imagePath.startsWith("www")) {
                // Load image from a URL
                Glide.with(mealImageView.getContext())
                        .load(imagePath)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .override(600, 600)
                        .into(mealImageView);
            } else {
                // Load image from drawable resources
                int imageResId = mealImageView.getContext().getResources()
                        .getIdentifier(imagePath, "drawable", mealImageView.getContext().getPackageName());
                if (imageResId != 0) {
                    Glide.with(mealImageView.getContext())
                            .load(imageResId)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .override(300, 300)
                            .into(mealImageView);
                } else {
                    mealImageView.setImageResource(R.drawable.default_image); // Fallback image
                }
            }
        } else if (imageBlob != null && imageBlob.length > 0) {
            // Load image from a byte array
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBlob, 0, imageBlob.length);
            mealImageView.setImageBitmap(bitmap);
        } else {
            mealImageView.setImageResource(R.drawable.default_image); // Fallback image
        }
    }

    //Updates the planner data and refreshes the RecyclerView.
    public void updateData(List<PlannerItem> newPlannerItems) {
        this.plannerItems.clear();
        this.plannerItems.addAll(newPlannerItems);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return plannerItems.size();
    }

    //Returns a planner item at a specific position, or null if the position is invalid.
    public PlannerItem getItem(int position) {
        if (position < 0 || position >= plannerItems.size()) {
            return null;
        }
        return plannerItems.get(position);
    }

    //Deletes a planner item at the specified position.
    public void deleteItem(int position) {
        if (position >= 0 && position < plannerItems.size()) {
            plannerItems.remove(position);
            notifyItemRemoved(position);
        }
    }

    //Toggles the status of a planner item between "eaten" and "not eaten".
    public void toggleStatus(int position) {
        if (position >= 0 && position < plannerItems.size()) {
            PlannerItem item = plannerItems.get(position);
            item.setStatus(item.getStatus() == 1 ? 0 : 1); // Toggle status
            notifyItemChanged(position);
        }
    }

    //ViewHolder class for holding views for each planner item.
    static class PlannerViewHolder extends RecyclerView.ViewHolder {
        TextView mealNameTextView, mealTypeTextView, dateTextView;
        ImageView mealImageView;

        public PlannerViewHolder(@NonNull View itemView) {
            super(itemView);
            mealNameTextView = itemView.findViewById(R.id.mealNameTextView);
            mealTypeTextView = itemView.findViewById(R.id.mealTypeTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            mealImageView = itemView.findViewById(R.id.mealImageView);
        }
    }
}