package com.example.cetandroidmobile.ui.shoppinglist;

public class ShoppingListItem {
    private String ingredientName;
    private String category;
    private boolean isPurchased;
    private String mealName;

    public ShoppingListItem(String ingredientName, String category, boolean isPurchased, String mealName) {
        this.ingredientName = ingredientName;
        this.category = category;
        this.isPurchased = isPurchased;
        this.mealName = mealName;
    }

    // Getter for ingredient name
    public String getIngredientName() {
        return ingredientName;
    }

    // Getter for category
    public String getCategory() {
        return category;
    }

    // Getter for purchased status
    public boolean isPurchased() {
        return isPurchased;
    }

    // Setter for purchased status
    public void setPurchased(boolean purchased) {
        this.isPurchased = purchased;
    }

    // Getter for meal name
    public String getMealName() {
        return mealName;
    }
}