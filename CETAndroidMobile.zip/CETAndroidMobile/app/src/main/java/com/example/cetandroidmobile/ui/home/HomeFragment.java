package com.example.cetandroidmobile.ui.home;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.cetandroidmobile.CreateMealActivity;
import com.example.cetandroidmobile.DBHelper;
import com.example.cetandroidmobile.LoginActivity;
import com.example.cetandroidmobile.MealDetails;
import com.example.cetandroidmobile.R;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    // UI components
    private RecyclerView recyclerViewMeals;
    private MealAdapter mealAdapter;

    // Database helper instance
    private DBHelper dbHelper;

    // User email retrieved from SharedPreferences
    private String userEmail;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize RecyclerView and set up layout manager
        recyclerViewMeals = view.findViewById(R.id.recyclerViewMeals);
        recyclerViewMeals.setLayoutManager(new GridLayoutManager(getActivity(), 2));

        // Initialize database helper
        dbHelper = new DBHelper(getActivity());

        // Retrieve user email from SharedPreferences
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("UserPrefs", getContext().MODE_PRIVATE);
        userEmail = sharedPreferences.getString("user_email", "");

        // Find and set up the "Create Own Meal" button
        Button buttonCreateMeal = view.findViewById(R.id.buttonCreateMeal);
        buttonCreateMeal.setOnClickListener(v -> handleCreateMealClick(sharedPreferences));

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Refresh the meal list when the fragment is resumed
        loadMeals();
    }

    //Handles the "Create Own Meal" button click event.
    private void handleCreateMealClick(SharedPreferences sharedPreferences) {
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);

        if (isLoggedIn) {
            if ("Guest".equals(userEmail)) {
                // Show alert dialog for guest users
                new AlertDialog.Builder(getActivity())
                        .setTitle("Login Required")
                        .setMessage("You need to log in or sign up to create your own meal.")
                        .setPositiveButton("Log In", (dialog, which) -> {
                            Intent intent = new Intent(getContext(), LoginActivity.class);
                            startActivity(intent);
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            } else {
                // Navigate to CreateMealActivity for logged-in users
                Intent intent = new Intent(getActivity(), CreateMealActivity.class);
                intent.putExtra("user_email", userEmail);
                startActivity(intent);
            }
        }
    }

    //Loads meals from the database and populates the RecyclerView.
    private void loadMeals() {
        List<Meal> mealList = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;

        try {
            // Retrieve user ID for non-guest users
            int userId = -1;
            if (!"Guest".equals(userEmail)) {
                userId = getUserIdFromEmail(userEmail);
                if (userId == -1) {
                    Toast.makeText(getActivity(), "User not found!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            // Query to fetch meals based on user type
            String query;
            String[] selectionArgs;
            if ("Guest".equals(userEmail)) {
                query = "SELECT * FROM meals WHERE created_by = 0 ORDER BY meal_id DESC";
                selectionArgs = null;
            } else {
                query = "SELECT * FROM meals WHERE created_by = 0 OR created_by = ? ORDER BY meal_id DESC";
                selectionArgs = new String[]{String.valueOf(userId)};
            }

            cursor = db.rawQuery(query, selectionArgs);

            // Iterate through the cursor to build the meal list
            if (cursor.moveToFirst()) {
                do {
                    int mealId = cursor.getInt(cursor.getColumnIndex("meal_id"));
                    String mealName = cursor.getString(cursor.getColumnIndex("meal_name"));
                    String mealType = cursor.getString(cursor.getColumnIndex("meal_type"));

                    // Load image data
                    Bitmap mealImage = null;
                    String imagePath = cursor.getString(cursor.getColumnIndex("image_path"));
                    byte[] imageBlob = cursor.getBlob(cursor.getColumnIndex("image_blob"));

                    // Attempt to load image from path
                    if (imagePath != null && !imagePath.isEmpty()) {
                        loadMealImage(imagePath, mealImage);
                    }

                    // Fallback to image BLOB if path fails
                    if (mealImage == null && imageBlob != null) {
                        mealImage = BitmapFactory.decodeByteArray(imageBlob, 0, imageBlob.length);
                    }

                    // Create a Meal object and add it to the list
                    Meal meal = new Meal(mealId, mealName, mealType, mealImage, imagePath, imageBlob);
                    mealList.add(meal);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Toast.makeText(getActivity(), "Error loading meals: " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }

        // Set the adapter to the RecyclerView
        mealAdapter = new MealAdapter(requireContext(), mealList);
        recyclerViewMeals.setAdapter(mealAdapter);
        mealAdapter.notifyDataSetChanged();

        // Set item click listener for the adapter
        mealAdapter.setOnItemClickListener(meal -> {
            Intent intent = new Intent(getActivity(), MealDetails.class);
            intent.putExtra("meal_id", meal.getMealId());
            intent.putExtra("user_email", userEmail);
            startActivity(intent);
        });
    }

    //Loads a meal image from the given path if valid.
    private void loadMealImage(String imagePath, Bitmap mealImage) {
        if (imagePath != null && !imagePath.isEmpty()) {
            int resourceId = requireContext().getResources().getIdentifier(imagePath, "drawable", requireContext().getPackageName());
            if (resourceId != 0) {
                mealImage = BitmapFactory.decodeResource(requireContext().getResources(), resourceId);
            }
        }
    }

    //Retrieves the user ID corresponding to the given email.
    private int getUserIdFromEmail(String email) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = null;
        int userId = -1;

        try {
            cursor = db.rawQuery("SELECT user_id FROM user WHERE email = ?", new String[]{email});
            if (cursor.moveToFirst()) {
                userId = cursor.getInt(cursor.getColumnIndex("user_id"));
            }
        } catch (Exception e) {
            Log.e("HomeFragment", "Error fetching user_id: " + e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return userId;
    }
}