package com.example.cetandroidmobile.ui.profile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.cetandroidmobile.DBHelper;
import com.example.cetandroidmobile.LoginActivity;
import com.example.cetandroidmobile.R;
import com.example.cetandroidmobile.databinding.FragmentProfileBinding;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ProfileFragment extends Fragment {
    private FragmentProfileBinding binding;
    private GoogleSignInClient gsc;
    private DBHelper dbHelper;
    private static final int PICK_IMAGE_REQUEST = 1;
    private String userEmail;
    private Bitmap selectedBitmap = null;
    private ImageView ivProfileImagePreview;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Set up the edit profile button
        binding.btnEditProfile.setOnClickListener(v -> showEditProfileDialog());

        binding.btnChangePassword.setOnClickListener(v -> showChangePasswordDialog());

        // Initialize Google Sign-In options and client
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        gsc = GoogleSignIn.getClient(requireActivity(), gso);

        // Initialize DBHelper
        dbHelper = new DBHelper(getActivity());

        // Retrieve the user's email from the arguments
        Bundle arguments = getArguments();
        if (arguments != null) {
            userEmail = arguments.getString("user_email", "Guest");

            // Check if user is logged in with Google
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(requireActivity());
            if (account != null && account.getEmail().equals(userEmail)) {
                // Display Google username and email
                binding.username.setText(account.getDisplayName());
                binding.email.setText(account.getEmail());

                // Check if the password is set for this user in the database
                boolean isPasswordSet = dbHelper.isPasswordSet(userEmail);

                if (isPasswordSet) {
                    binding.btnChangePassword.setVisibility(View.VISIBLE);
                    binding.btnSetPassword.setVisibility(View.GONE);
                } else {
                    binding.btnSetPassword.setVisibility(View.VISIBLE);
                    binding.btnChangePassword.setVisibility(View.GONE);
                }
            } else {
                // Retrieve username from the database using the email if not signed in with Google
                String username = dbHelper.getUsernameByEmail(userEmail);
                binding.username.setText(username != null ? username : "Username not found");
                binding.email.setText(userEmail != null ? userEmail : "No email provided");

                binding.btnChangePassword.setVisibility(View.VISIBLE);
                binding.btnSetPassword.setVisibility(View.GONE);
            }
            // Load and display profile image
            loadProfileImage(userEmail);
        } else {
            binding.email.setText("No email provided");
            binding.username.setText("Username not found");
        }

        // Retrieve the counts and update the UI
        if (userEmail != null) {
            int createdCount = getCreatedCount(userEmail);
            int plannerCount = getPlannerCount(userEmail);
            int listCount = getListCount(userEmail);

            binding.tvCreatedCount.setText(String.valueOf(createdCount));
            binding.tvPlannerCount.setText(String.valueOf(plannerCount));
            binding.tvListCount.setText(String.valueOf(listCount));
        }
        // Set up the sign-out button
        binding.btnLogout.setOnClickListener(v -> logout());

        // Set up the "Set Password" button to show the dialog when clicked
        binding.btnSetPassword.setOnClickListener(v -> showSetPasswordDialog());

        return root;
    }

    // Load and display profile image from database
    private void loadProfileImage(String email) {
        byte[] imageBytes = dbHelper.getProfileImageByEmail(email);
        if (imageBytes != null) {
            Bitmap profileBitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            binding.profilePicture.setImageBitmap(profileBitmap);
        } else {
            binding.profilePicture.setImageResource(R.drawable.ic_profile_placeholder);
        }
    }

    // Open the image picker
    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    // Handle the image selection result
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri != null) {
                try {
                    selectedBitmap = MediaStore.Images.Media.getBitmap(requireActivity().getContentResolver(), imageUri);

                    // Show selected image in dialog preview if dialog is open
                    if (ivProfileImagePreview != null) {
                        ivProfileImagePreview.setImageBitmap(selectedBitmap);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Save the image as BLOB in the database
    private void saveImageToDatabase(Bitmap bitmap) {
        // Convert Bitmap to byte array
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] imageByteArray = stream.toByteArray();

        // Insert the image as BLOB into the database
        boolean result = dbHelper.saveProfileImage(userEmail, imageByteArray);
    }

    private void logout() {
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("UserPrefs", requireActivity().MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        // Check if it was a Google Sign-In
        if (gsc != null) {
            gsc.signOut().addOnCompleteListener(task -> {
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                getActivity().finish();
            });
        } else {
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            getActivity().finish();
        }
    }

    private void showSetPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle("Set Password");
        builder.setMessage("You need to set a password for your account.");

        // Inflate the custom layout
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_set_password, null);
        builder.setView(dialogView);

        // Get references to the UI elements
        EditText newPasswordInput = dialogView.findViewById(R.id.new_password_input);
        EditText confirmPasswordInput = dialogView.findViewById(R.id.confirm_password_input);
        ImageButton showPasswordButton1 = dialogView.findViewById(R.id.show_password_button1);
        ImageButton showPasswordButton2 = dialogView.findViewById(R.id.show_password_button2);

        // Handle "Show/Hide Password" functionality for New Password
        showPasswordButton1.setOnClickListener(v -> {
            if (newPasswordInput.getTransformationMethod() instanceof PasswordTransformationMethod) {
                newPasswordInput.setTransformationMethod(null);
                showPasswordButton1.setImageResource(R.drawable.ic_eye_closed);
            } else {
                newPasswordInput.setTransformationMethod(PasswordTransformationMethod.getInstance());
                showPasswordButton1.setImageResource(R.drawable.ic_eye_open);
            }
            newPasswordInput.setSelection(newPasswordInput.getText().length());
        });

        // Handle "Show/Hide Password" functionality for Confirm Password
        showPasswordButton2.setOnClickListener(v -> {
            if (confirmPasswordInput.getTransformationMethod() instanceof PasswordTransformationMethod) {
                confirmPasswordInput.setTransformationMethod(null);
                showPasswordButton2.setImageResource(R.drawable.ic_eye_closed);
            } else {
                confirmPasswordInput.setTransformationMethod(PasswordTransformationMethod.getInstance());
                showPasswordButton2.setImageResource(R.drawable.ic_eye_open);
            }
            confirmPasswordInput.setSelection(confirmPasswordInput.getText().length());
        });

        // Set up the buttons
        builder.setPositiveButton("Set", (dialog, which) -> {
            String newPassword = newPasswordInput.getText().toString().trim();
            String confirmPassword = confirmPasswordInput.getText().toString().trim();

            // Reset errors first
            newPasswordInput.setError(null);
            confirmPasswordInput.setError(null);

            // Validate password fields
            if (newPassword.isEmpty()) {
                newPasswordInput.setError("New password is required.");
                newPasswordInput.requestFocus();
            } else if (confirmPassword.isEmpty()) {
                confirmPasswordInput.setError("Please confirm your password.");
                confirmPasswordInput.requestFocus();
            } else if (!newPassword.equals(confirmPassword)) {
                newPasswordInput.setError("Passwords do not match.");
                confirmPasswordInput.setError("Passwords do not match.");
                newPasswordInput.requestFocus();
            } else if (!isStrongPassword(newPassword)) {
                newPasswordInput.setError("Password is not strong enough.");
                newPasswordInput.requestFocus();
            } else {
                // Update password in the database
                dbHelper.updatePassword(userEmail, newPassword);
                Toast.makeText(requireActivity(), "Password set successfully!", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                binding.btnChangePassword.setVisibility(View.VISIBLE);
                binding.btnSetPassword.setVisibility(View.GONE);
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    // Helper method to validate strong password
    private boolean isStrongPassword(String password) {
        // Regular expression to check for strong password criteria
        String passwordPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        return password.matches(passwordPattern);
    }

    private void showEditProfileDialog() {
        // Inflate the dialog's layout
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.edit_profile_dialog, null);

        EditText etUsername = dialogView.findViewById(R.id.et_username);
        EditText etEmail = dialogView.findViewById(R.id.et_email);
        ivProfileImagePreview = dialogView.findViewById(R.id.iv_profile_image_preview);
        TextView tvClearImage = dialogView.findViewById(R.id.tv_clear_image);

        // Pre-fill existing details
        etUsername.setText(binding.username.getText());
        etEmail.setText(binding.email.getText());

        // Disable email field
        etEmail.setEnabled(false);

        // Display current profile image in the preview
        byte[] imageBytes = dbHelper.getProfileImageByEmail(userEmail);
        if (imageBytes != null) {
            Bitmap profileBitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            ivProfileImagePreview.setImageBitmap(profileBitmap);
        } else {
            ivProfileImagePreview.setImageResource(R.drawable.ic_profile_placeholder);
        }

        // Set up ImageView click listener for selecting an image
        ivProfileImagePreview.setOnClickListener(v -> openImagePicker());

        // Set up clear image TextView click listener
        tvClearImage.setOnClickListener(v -> {
            ivProfileImagePreview.setImageResource(R.drawable.ic_profile_placeholder); // Reset to placeholder
            selectedBitmap = null; // Clear the selected bitmap
        });

        // Create and configure the dialog
        new android.app.AlertDialog.Builder(getActivity())
                .setTitle("Edit Profile")
                .setView(dialogView)
                .setCancelable(true)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newUsername = etUsername.getText().toString();
                    String newEmail = etEmail.getText().toString();

                    // Save updated profile details
                    saveUpdatedProfile(newUsername, newEmail);

                    // Save the profile picture if updated or reset it if cleared
                    if (selectedBitmap != null) {
                        saveImageToDatabase(selectedBitmap);
                        binding.profilePicture.setImageBitmap(selectedBitmap);
                    } else {
                        dbHelper.deleteProfileImage(userEmail); // Remove image from database
                        binding.profilePicture.setImageResource(R.drawable.ic_profile_placeholder);
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }


    private void showChangePasswordDialog() {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_change_password, null);

        EditText etOldPassword = dialogView.findViewById(R.id.et_old_password);
        EditText etNewPassword = dialogView.findViewById(R.id.et_new_password);
        EditText etConfirmPassword = dialogView.findViewById(R.id.et_confirm_password);

        // Create and set up the "eye" button for the new password field
        ImageButton showNewPasswordButton = dialogView.findViewById(R.id.btn_show_new_password);
        showNewPasswordButton.setImageResource(R.drawable.ic_eye_open);
        showNewPasswordButton.setOnClickListener(v -> {
            togglePasswordVisibility(etNewPassword, showNewPasswordButton);
        });

        // Create and set up the "eye" button for the confirm password field
        ImageButton showConfirmPasswordButton = dialogView.findViewById(R.id.btn_show_confirm_password);
        showConfirmPasswordButton.setImageResource(R.drawable.ic_eye_open);
        showConfirmPasswordButton.setOnClickListener(v -> {
            togglePasswordVisibility(etConfirmPassword, showConfirmPasswordButton);
        });

        new android.app.AlertDialog.Builder(requireContext())
                .setTitle("Change Password")
                .setView(dialogView)
                .setPositiveButton("Change", (dialog, which) -> {
                    String oldPassword = etOldPassword.getText().toString().trim();
                    String newPassword = etNewPassword.getText().toString().trim();
                    String confirmPassword = etConfirmPassword.getText().toString().trim();

                    // Validate the password fields
                    if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                        showCustomToast("Please fill in all fields!", R.drawable.ic_error);
                    } else if (!newPassword.equals(confirmPassword)) {
                        showCustomToast("Passwords do not match!", R.drawable.ic_error);
                    } else if (!isStrongPassword(newPassword)) {
                        showCustomToast("New password is not strong enough. It must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.", R.drawable.ic_error);
                    } else {
                        // Verify old password and update the password
                        boolean result = dbHelper.changePassword(userEmail, oldPassword, newPassword);
                        if (result) {
                            showCustomToast("Password changed successfully", R.drawable.ic_success);
                        } else {
                            showCustomToast("Failed to change password. Please try again.", R.drawable.ic_error);
                        }
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    // Utility method to toggle the visibility of a password field
    private void togglePasswordVisibility(EditText editText, ImageButton button) {
        // Check if the current transformation method is set to hide the password
        if (editText.getTransformationMethod() instanceof PasswordTransformationMethod) {
            // Change to visible password
            editText.setTransformationMethod(null);
            button.setImageResource(R.drawable.ic_eye_closed); // Set the eye closed icon
        } else {
            // Change to password input
            editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
            button.setImageResource(R.drawable.ic_eye_open); // Set the eye open icon
        }

        editText.setSelection(editText.getText().length());
    }

    // Save updated profile details to the database
    private void saveUpdatedProfile(String newUsername, String newEmail) {
        // Validation for username and email
        if (newUsername == null || newUsername.trim().isEmpty()) {
            showCustomToast("Username cannot be blank!", R.drawable.ic_error);
            return;
        }

        // Check if user is signed in with Google and email is being changed
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(requireActivity());
        if (account != null && account.getEmail().equals(userEmail)) {
            // User signed in with Google; prevent email change
            if (!newEmail.equals(userEmail)) {
                showCustomToast("You cannot change your email when signed in with Google!", R.drawable.ic_error);
                return;
            }
        }

        if (newEmail == null || newEmail.trim().isEmpty()) {
            showCustomToast("Email cannot be blank!", R.drawable.ic_error);
            return;
        }

        boolean result = dbHelper.updateUserProfile(userEmail, newUsername, newEmail);

        if (result) {
            // Update UI and SharedPreferences
            binding.username.setText(newUsername);
            binding.email.setText(newEmail);

            SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("UserPrefs", requireActivity().MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("user_email", newEmail);
            editor.apply();

            // Show success Toast
            showCustomToast("Profile updated successfully!", R.drawable.ic_success);
        } else {
            // Show failure Toast
            showCustomToast("Failed to update profile!", R.drawable.ic_error);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void showCustomToast(String message, int iconResId) {
        LayoutInflater inflater = LayoutInflater.from(requireContext());
        View customView = inflater.inflate(R.layout.custom_toast, null);

        TextView toastMessage = customView.findViewById(R.id.toast_message);
        ImageView toastIcon = customView.findViewById(R.id.toast_icon);

        toastMessage.setText(message);
        toastIcon.setImageResource(iconResId);

        // Create and display the custom Toast
        Toast customToast = new Toast(requireContext());
        customToast.setDuration(Toast.LENGTH_SHORT);
        customToast.setView(customView);
        customToast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 100); // Position the Toast
        customToast.show();
    }

    private int getCreatedCount(String userEmail) {
        int count = 0;
        int userId = dbHelper.getUserIdByEmail(userEmail);
        // Method to get the user ID from email
        if (userId != -1) {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM meals WHERE created_by = ?", new String[]{String.valueOf(userId)});

            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
            cursor.close();
        }
        return count;
    }

    private int getPlannerCount(String userEmail) {
        int count = 0;
        int userId = dbHelper.getUserIdByEmail(userEmail);

        if (userId != -1) {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM planner WHERE user_id = ?", new String[]{String.valueOf(userId)});

            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
            cursor.close();
        }
        return count;
    }

    private int getListCount(String userEmail) {
        int count = 0;
        int userId = dbHelper.getUserIdByEmail(userEmail);

        if (userId != -1) {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM shopping_list WHERE user_id = ?", new String[]{String.valueOf(userId)});

            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
            cursor.close();
        }
        return count;
    }
}