package com.example.cetandroidmobile.ui.dashboard;

public class PlannerItem {
    private int plannerId;
    private int mealId;
    private String mealName;
    private String mealType;
    private String date;
    private String imagePath;
    private byte[] imageBlob;
    private int status;

    public PlannerItem(int plannerId, int mealId, String mealName, String mealType, String date, String imagePath, byte[] imageBlob, int status) {
        this.plannerId = plannerId;
        this.mealId = mealId;
        this.mealName = mealName;
        this.mealType = mealType;
        this.date = date;
        this.imagePath = imagePath;
        this.imageBlob = imageBlob;
        this.status = status;
    }


    public int getPlannerId() {
        return plannerId;
    }
    public void setPlannerId(int plannerId) {
        this.plannerId = plannerId;
    }


    public int getMealId() {
        return mealId;
    }
    public void setMealId(int mealId) {
        this.mealId = mealId;
    }


    public String getMealName() {
        return mealName;
    }
    public void setMealName(String mealName) {
        this.mealName = mealName;
    }


    public String getMealType() {
        return mealType;
    }
    public void setMealType(String mealType) {
        this.mealType = mealType;
    }


    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }


    public String getImagePath() {
        return imagePath;
    }
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }


    public byte[] getImageBlob() {
        return imageBlob;
    }
    public void setImageBlob(byte[] imageBlob) {
        this.imageBlob = imageBlob;
    }


    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    }
}
