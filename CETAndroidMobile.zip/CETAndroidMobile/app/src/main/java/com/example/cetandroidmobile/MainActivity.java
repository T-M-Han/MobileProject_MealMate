package com.example.cetandroidmobile;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.cetandroidmobile.databinding.ActivityMainBinding;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    // Database helper instance
    DBHelper dbHelper;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get user preferences for login status
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
        boolean isGoogleSignIn = sharedPreferences.getBoolean("isGoogleSignIn", false);
        String userEmail = sharedPreferences.getString("user_email", null);
        boolean isGuest = "Guest".equals(userEmail);

        // Redirect to LoginActivity if the user is not logged in and not a guest
        if (!isLoggedIn && !isGoogleSignIn && !isGuest) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Close MainActivity to prevent it from being in the back stack
            return;
        }

        // Set up the view binding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Setup bottom navigation view and navigation controller
        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home,
                R.id.navigation_dashboard,
                R.id.navigation_shoppinglist,
                R.id.navigation_profile)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);

        // Configure the action bar with the navigation controller
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        // Connect bottom navigation view with navigation controller
        NavigationUI.setupWithNavController(binding.navView, navController);

        // Prepare data bundle for passing user email to fragments
        Bundle bundle = new Bundle();
        bundle.putString("user_email", userEmail);

        // Handle navigation item selection
        binding.navView.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.navigation_home) {
                navController.navigate(R.id.navigation_home, bundle); // Navigate to HomeFragment
                return true;
            } else if (itemId == R.id.navigation_dashboard) {
                navController.navigate(R.id.navigation_dashboard); // Navigate to DashboardFragment
                return true;
            } else if (itemId == R.id.navigation_shoppinglist) {
                navController.navigate(R.id.navigation_shoppinglist); // Navigate to ShoppingListFragment
                return true;
            } else if (itemId == R.id.navigation_profile) {
                // Navigate to GuestProfileFragment if the user is logged in as a guest
                if (isGuest) {
                    navController.navigate(R.id.navigation_guest_profile);
                } else {
                    navController.navigate(R.id.navigation_profile, bundle); // Navigate to ProfileFragment
                }
                return true;
            } else {
                return false; // Item selection not handled
            }
        });

        // Initialize database helper and make sure database connection is established
        dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Navigate to HomeFragment when the activity starts
        navController.navigate(R.id.navigation_home, bundle);
    }

    // Handle navigation up button press
    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        return NavigationUI.navigateUp(navController, new AppBarConfiguration.Builder(R.id.navigation_home).build())
                || super.onSupportNavigateUp();
    }
}
