package com.example.cetandroidmobile;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

public class LoginActivity extends AppCompatActivity {

    // Declare Google Sign-In components
    GoogleSignInOptions gso;
    GoogleSignInClient gsc;

    // UI components
    Button googlebtn, loginButton;
    EditText emailInput, passwordInput;
    TextView signupRedirect, guestLogin;
    ImageButton showPasswordButton;
    DBHelper dbHelper;

    private boolean isPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize DBHelper for user authentication
        dbHelper = new DBHelper(this);

        // Link UI components from layout
        googlebtn = findViewById(R.id.googleSignInButton);
        emailInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        signupRedirect = findViewById(R.id.signupRedirect);
        guestLogin = findViewById(R.id.guestLogin);
        showPasswordButton = findViewById(R.id.showPasswordButton);

        // Configure Google Sign-In options
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        gsc = GoogleSignIn.getClient(this, gso);

        // Set up button click listeners
        googlebtn.setOnClickListener(v -> signin()); // Start Google Sign-In
        loginButton.setOnClickListener(v -> validateAndLogin()); // Validate login credentials
        signupRedirect.setOnClickListener(v -> navigateToSignup()); // Redirect to signup activity
        guestLogin.setOnClickListener(v -> loginAsGuest()); // Handle guest login
        showPasswordButton.setOnClickListener(v -> togglePasswordVisibility()); // Toggle password visibility
    }

    // Method to validate user input and log in if valid
    private void validateAndLogin() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (email.isEmpty()) {
            emailInput.setError("Email is required");
            emailInput.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            passwordInput.setError("Password is required");
            passwordInput.requestFocus();
            return;
        }

        // Verify user with database
        boolean isValid = dbHelper.verifyUser(email, password);
        if (isValid) {
            // Save user login status
            SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("isLoggedIn", true);
            editor.putString("user_email", email);
            editor.apply();

            showCustomToast("Logged in successfully", true);

            // Navigate to MainActivity
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            intent.putExtra("user_email", email);
            startActivity(intent);
            finish();
        } else {
            showCustomToast("Invalid email or password", false);
        }
    }

    // Method to handle Google Sign-In
    void signin() {
        Intent signinIntent = gsc.getSignInIntent();
        startActivityForResult(signinIntent, 1000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1000) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                navigateToMainActivity(account.getEmail(), account.getDisplayName());
            } catch (ApiException e) {
                Log.e("GoogleSignInError", "Google sign-in failed: " + e.getStatusCode());
                showCustomToast("Google sign-in failed", false);
            }
        }
    }

    // Navigate to MainActivity after successful Google Sign-In
    void navigateToMainActivity(String email, String username) {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", true);
        editor.putBoolean("isGoogleSignIn", true);
        editor.putString("user_email", email);
        editor.apply();

        // Check if user already exists in the database, add if not
        if (dbHelper.getUsernameByEmail(email) == null) {
            boolean isInserted = dbHelper.insertGoogleUser(username, email);
            if (!isInserted) {
                showCustomToast("Failed to save Google account to the database.", false);
                return;
            }
        }

        showCustomToast("Google login successful", true);
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.putExtra("user_email", email != null ? email : "Guest");
        intent.putExtra("username", username != null ? username : "Guest");
        startActivity(intent);
        finish();
    }

    // Toggle password visibility (show/hide)
    private void togglePasswordVisibility() {
        if (isPasswordVisible) {
            passwordInput.setTransformationMethod(PasswordTransformationMethod.getInstance());
            showPasswordButton.setImageResource(R.drawable.ic_eye_closed);
        } else {
            passwordInput.setTransformationMethod(null);
            showPasswordButton.setImageResource(R.drawable.ic_eye_open);
        }
        isPasswordVisible = !isPasswordVisible;
        passwordInput.setSelection(passwordInput.getText().length());
    }

    // Login as a guest user
    private void loginAsGuest() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", true);
        editor.putString("user_email", "Guest");
        editor.apply();

        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    // Navigate to signup activity
    private void navigateToSignup() {
        Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
        startActivity(intent);
    }

    // Custom Toast for showing messages
    private void showCustomToast(String message, boolean isSuccess) {
        LayoutInflater inflater = getLayoutInflater();
        View toastLayout = inflater.inflate(R.layout.custom_toast, null);
        TextView toastMessage = toastLayout.findViewById(R.id.toast_message);
        toastMessage.setText(message);

        ImageView toastIcon = toastLayout.findViewById(R.id.toast_icon);
        if (isSuccess) {
            toastIcon.setImageResource(R.drawable.ic_success);
        } else {
            toastIcon.setImageResource(R.drawable.ic_error);
        }

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastLayout);
        toast.show();
    }
}
