package com.example.cetandroidmobile.ui.shoppinglist;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cetandroidmobile.DBHelper;
import com.example.cetandroidmobile.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShoppingListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_CATEGORY = 0;
    private static final int VIEW_TYPE_ITEM = 1;
    private final List<Object> groupedData;
    private final DBHelper dbHelper;
    private final Context context;
    private final Fragment fragment;

    public ShoppingListAdapter(Map<String, List<ShoppingListItem>> groupedItems, Fragment fragment, Context context) {
        this.groupedData = new ArrayList<>();
        this.dbHelper = new DBHelper(context);
        this.context = context;
        this.fragment = fragment;

        for (String category : groupedItems.keySet()) {
            groupedData.add(category);
            groupedData.addAll(groupedItems.get(category));
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (groupedData.get(position) instanceof String) {
            return VIEW_TYPE_CATEGORY;
        } else {
            return VIEW_TYPE_ITEM;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_CATEGORY) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.shopping_list_category_header, parent, false);
            return new CategoryViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.shopping_list_item, parent, false);
            return new ItemViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof CategoryViewHolder) {
            // Bind category header
            ((CategoryViewHolder) holder).categoryName.setText((String) groupedData.get(position));
        } else if (holder instanceof ItemViewHolder) {
            // Bind individual shopping list item
            ShoppingListItem item = (ShoppingListItem) groupedData.get(position);

            // Set ingredient name
            ((ItemViewHolder) holder).ingredientName.setText(item.getIngredientName());

            // Set purchased checkbox
            ((ItemViewHolder) holder).checkBox.setChecked(item.isPurchased());

            // Set meal name
            ((ItemViewHolder) holder).mealName.setText("For: " + item.getMealName());

            // Handle checkbox toggle
            ((ItemViewHolder) holder).checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                updatePurchaseStatus(item, isChecked);
            });
        }
    }

    @Override
    public int getItemCount() {
        return groupedData.size();
    }

    private void updatePurchaseStatus(ShoppingListItem item, boolean isPurchased) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("is_purchased", isPurchased ? 1 : 0);

        int rowsUpdated = db.update(
                "shopping_list",
                values,
                "ingredient_name = ?",
                new String[]{item.getIngredientName()}
        );

        if (rowsUpdated > 0) {
            item.setPurchased(isPurchased);
            if (fragment instanceof ShoppingListFragment) {
                ((ShoppingListFragment) fragment).showCustomToast(
                        isPurchased ? "Marked as Purchased" : "Marked as Not Purchased",
                        true
                );
            }
        }
        db.close();
    }

    public void removeItem(int position) {
        Object item = groupedData.get(position);
        if (item instanceof ShoppingListItem) {
            ShoppingListItem shoppingItem = (ShoppingListItem) item;

            SQLiteDatabase db = dbHelper.getWritableDatabase();
            int rowsDeleted = db.delete(
                    "shopping_list",
                    "ingredient_name = ?",
                    new String[]{shoppingItem.getIngredientName()}
            );

            if (rowsDeleted > 0) {
                groupedData.remove(position);
                notifyItemRemoved(position);

                if (fragment instanceof ShoppingListFragment) {
                    ((ShoppingListFragment) fragment).showCustomToast("Item deleted", true);
                }
            }
            db.close();
        }
    }

    public static class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView categoryName;

        public CategoryViewHolder(View itemView) {
            super(itemView);
            categoryName = itemView.findViewById(R.id.categoryName);
        }
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView ingredientName;
        TextView mealName;
        CheckBox checkBox;
        public ItemViewHolder(View itemView) {
            super(itemView);
            ingredientName = itemView.findViewById(R.id.ingredientName);
            mealName = itemView.findViewById(R.id.ingredientMealName);
            checkBox = itemView.findViewById(R.id.checkBoxPurchased);
        }
    }

    public void updateData(Map<String, List<ShoppingListItem>> groupedItems) {
        groupedData.clear();
        for (String category : groupedItems.keySet()) {
            groupedData.add(category);
            groupedData.addAll(groupedItems.get(category));
        }
        notifyDataSetChanged();
    }
}