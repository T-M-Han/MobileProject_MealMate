package com.example.cetandroidmobile;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Delay for splash screen to display for 3 seconds
        new Handler().postDelayed(() -> {
            // Check if a user is signed in with Google
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);

            Intent intent;
            if (account != null) {
                // If user is signed in with Google, navigate to MainActivity
                intent = new Intent(SplashActivity.this, MainActivity.class);
                intent.putExtra("user_email", account.getEmail()); // Pass Google email
            } else {
                // If no Google sign-in, check shared preferences for email/password login
                SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
                String userEmail = sharedPreferences.getString("user_email", null);

                if (isLoggedIn && userEmail != null) {
                    // If user is logged in with email/password, navigate to MainActivity
                    intent = new Intent(SplashActivity.this, MainActivity.class);
                    intent.putExtra("user_email", userEmail); // Pass stored email
                } else {
                    // If not logged in, navigate to LoginActivity
                    intent = new Intent(SplashActivity.this, LoginActivity.class);
                }
            }

            // Start the next activity and close SplashActivity
            startActivity(intent);
            finish(); // Finish SplashActivity so it can't be accessed with the back button
        }, 3000); // Set splash screen delay to 3 seconds
    }
}