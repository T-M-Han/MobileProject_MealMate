package com.example.cetandroidmobile.ui.home;

import android.graphics.Bitmap;

public class Meal {
    private int mealId;
    private String mealName;
    private String mealType;
    private Bitmap mealImage;
    private String imagePath;
    private byte[] imageBlob;

    // Constructor
    public Meal(int mealId, String mealName, String mealType, Bitmap mealImage, String imagePath, byte[] imageBlob) {
        this.mealId = mealId;
        this.mealName = mealName;
        this.mealType = mealType;
        this.mealImage = mealImage;
        this.imagePath = imagePath;
        this.imageBlob = imageBlob;
    }

    // Getter for mealId
    public int getMealId() {
        return mealId;
    }

    // Getter for mealName
    public String getMealName() {
        return mealName;
    }

    // Getter for mealType
    public String getMealType() {
        return mealType;
    }

    // Getter for mealImage
    public Bitmap getMealImage() {
        return mealImage;
    }

    // Getter for imagePath
    public String getImagePath() {
        return imagePath;
    }

    // Getter for imageBlob
    public byte[] getImageBlob() {
        return imageBlob;
    }
}
