package com.example.cetandroidmobile.ui.guest;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.cetandroidmobile.LoginActivity;
import com.example.cetandroidmobile.R;
import com.example.cetandroidmobile.SignupActivity;

public class GuestProfileFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for the guest profile screen
        View view = inflater.inflate(R.layout.fragment_guest_profile, container, false);

        // Initialize UI components
        Button loginButton = view.findViewById(R.id.btn_login);
        Button signUpButton = view.findViewById(R.id.btn_sign_up);

        // Set click listener for the "Login" button
        loginButton.setOnClickListener(v -> {
            // Navigate to LoginActivity
            Intent loginIntent = new Intent(getActivity(), LoginActivity.class);
            startActivity(loginIntent);
        });

        // Set click listener for the "Sign Up" button
        signUpButton.setOnClickListener(v -> {
            // Navigate to SignupActivity
            Intent signUpIntent = new Intent(getActivity(), SignupActivity.class);
            startActivity(signUpIntent);
        });

        return view; // Return the inflated view
    }
}