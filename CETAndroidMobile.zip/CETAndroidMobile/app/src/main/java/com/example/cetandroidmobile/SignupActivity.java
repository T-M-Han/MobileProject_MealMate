package com.example.cetandroidmobile;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    // UI elements
    private EditText signupUsername, signupEmail, signupPassword, signupConfirmPassword;
    private DBHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initialize UI components
        signupUsername = findViewById(R.id.signupUsername);
        signupEmail = findViewById(R.id.signupEmail);
        signupPassword = findViewById(R.id.signupPassword);
        signupConfirmPassword = findViewById(R.id.signupConfirmPassword);
        Button signupButton = findViewById(R.id.signupButton);
        TextView backToLogin = findViewById(R.id.backToLogin);

        // Initialize Database Helper
        databaseHelper = new DBHelper(this);

        // Set up password visibility toggle buttons
        ImageButton showPasswordButton = findViewById(R.id.showPasswordButton);
        ImageButton showConfirmPasswordButton = findViewById(R.id.showConfirmPasswordButton);

        // Toggle visibility for password field
        showPasswordButton.setOnClickListener(new View.OnClickListener() {
            private boolean isPasswordVisible = false;

            @Override
            public void onClick(View v) {
                isPasswordVisible = !isPasswordVisible; // Toggle password visibility
                togglePasswordVisibility(signupPassword, isPasswordVisible, showPasswordButton);
            }
        });

        // Toggle visibility for confirm password field
        showConfirmPasswordButton.setOnClickListener(new View.OnClickListener() {
            private boolean isConfirmPasswordVisible = false;

            @Override
            public void onClick(View v) {
                isConfirmPasswordVisible = !isConfirmPasswordVisible; // Toggle confirm password visibility
                togglePasswordVisibility(signupConfirmPassword, isConfirmPasswordVisible, showConfirmPasswordButton);
            }
        });

        // Set listener for the sign-up button
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser(); // Call registration method
            }
        });

        // Navigate back to login screen
        backToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Finish current activity
            }
        });
    }

    // Toggle password visibility and update the icon
    private void togglePasswordVisibility(EditText passwordField, boolean isVisible, ImageButton toggleButton) {
        if (isVisible) {
            passwordField.setTransformationMethod(PasswordTransformationMethod.getInstance()); // Show password
            toggleButton.setImageResource(R.drawable.ic_eye_open); // Set open eye icon
        } else {
            passwordField.setTransformationMethod(null); // Hide password
            toggleButton.setImageResource(R.drawable.ic_eye_closed); // Set closed eye icon
        }
        passwordField.setSelection(passwordField.getText().length()); // Move cursor to end
    }

    // Method to register a new user
    private void registerUser() {
        clearSharedPreferences(); // Clear shared preferences for a fresh start

        // Retrieve input values
        String username = signupUsername.getText().toString().trim();
        String email = signupEmail.getText().toString().trim();
        String password = signupPassword.getText().toString().trim();
        String confirmPassword = signupConfirmPassword.getText().toString().trim();

        // Validate input fields
        if (TextUtils.isEmpty(username)) {
            signupUsername.setError("Username is required");
            return;
        }
        if (TextUtils.isEmpty(email) || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            signupEmail.setError("Valid email is required");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            signupPassword.setError("Password is required");
            return;
        }
        if (!validatePasswordStrength(password)) {
            return; // Error messages shown within `validatePasswordStrength`
        }
        if (!password.equals(confirmPassword)) {
            signupConfirmPassword.setError("Passwords do not match");
            return;
        }

        // Check if email is already registered
        SQLiteDatabase db = databaseHelper.getReadableDatabase();
        String[] columns = {"email"};
        String selection = "email = ?";
        String[] selectionArgs = {email};

        Cursor cursor = db.query("user", columns, selection, selectionArgs, null, null, null);
        boolean emailExists = cursor.getCount() > 0;
        cursor.close();

        if (emailExists) {
            signupEmail.setError("Email is already registered");
            return;
        }

        // Insert new user into database
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("email", email);
        values.put("password", password);

        long newRowId = db.insert("user", null, values);
        if (newRowId != -1) {
            showCustomToast("User registered successfully", true); // Success toast

            // Navigate to MainActivity and pass data
            Intent intent = new Intent(SignupActivity.this, MainActivity.class);
            intent.putExtra("username", username);
            intent.putExtra("user_email", email);
            startActivity(intent);
            finish(); // Finish current activity
        } else {
            showCustomToast("Registration failed", false); // Failure toast
        }
    }

    // Validate password strength based on criteria
    private boolean validatePasswordStrength(String password) {
        if (password.length() < 8) {
            signupPassword.setError("Password must be at least 8 characters long");
            return false;
        }
        if (!password.matches(".*[A-Z].*")) {
            signupPassword.setError("Password must contain at least one uppercase letter");
            return false;
        }
        if (!password.matches(".*[a-z].*")) {
            signupPassword.setError("Password must contain at least one lowercase letter");
            return false;
        }
        if (!password.matches(".*\\d.*")) {
            signupPassword.setError("Password must contain at least one number");
            return false;
        }
        if (!password.matches(".*[@#\\$%^&+=!*?~].*")) {
            signupPassword.setError("Password must contain at least one special character (@, #, $, etc.)");
            return false;
        }
        return true;
    }

    // Display custom toast messages
    private void showCustomToast(String message, boolean isSuccess) {
        LayoutInflater inflater = getLayoutInflater();
        View toastLayout = inflater.inflate(R.layout.custom_toast, null); // Inflate custom toast layout

        // Set message text
        TextView toastMessage = toastLayout.findViewById(R.id.toast_message);
        toastMessage.setText(message);

        // Set icon based on success or failure
        ImageView toastIcon = toastLayout.findViewById(R.id.toast_icon);
        if (isSuccess) {
            toastIcon.setImageResource(R.drawable.ic_success); // Success icon
        } else {
            toastIcon.setImageResource(R.drawable.ic_error); // Error icon
        }

        // Display the custom toast
        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(toastLayout);
        toast.show();
    }

    // Clear shared preferences data
    private void clearSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear(); // Clear all preferences
        editor.apply(); // Apply changes
    }
}
